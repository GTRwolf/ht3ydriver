/** @file
 *  @brief MAVLink comm protocol generated from ht3y.xml
 *  @see http://mavlink.org
 */
#pragma once
#ifndef MAVLINK_HT3Y_H
#define MAVLINK_HT3Y_H

#ifndef MAVLINK_H
    #error Wrong include order: MAVLINK_HT3Y.H MUST NOT BE DIRECTLY USED. Include mavlink.h from the same directory instead or set ALL AND EVERY defines from MAVLINK.H manually accordingly, including the #define MAVLINK_H call.
#endif

#undef MAVLINK_THIS_XML_IDX
#define MAVLINK_THIS_XML_IDX 2

#ifdef __cplusplus
extern "C" {
#endif

// MESSAGE LENGTHS AND CRCS

#ifndef MAVLINK_MESSAGE_LENGTHS
#define MAVLINK_MESSAGE_LENGTHS {}
#endif

#ifndef MAVLINK_MESSAGE_CRCS
#define MAVLINK_MESSAGE_CRCS {{200, 80, 110, 110, 0, 0, 0}, {201, 173, 24, 24, 0, 0, 0}, {202, 96, 36, 36, 0, 0, 0}}
#endif

#include "../protocol.h"

#define MAVLINK_ENABLED_HT3Y

// ENUM DEFINITIONS



// MAVLINK VERSION

#ifndef MAVLINK_VERSION
#define MAVLINK_VERSION 2
#endif

#if (MAVLINK_VERSION == 0)
#undef MAVLINK_VERSION
#define MAVLINK_VERSION 2
#endif

// MESSAGE DEFINITIONS
#include "./mavlink_msg_px4tonuc.h"
#include "./mavlink_msg_nuc_action_cont.h"
#include "./mavlink_msg_nuc_mode_cont.h"

// base include
#include "../common/common.h"

#undef MAVLINK_THIS_XML_IDX
#define MAVLINK_THIS_XML_IDX 2

#if MAVLINK_THIS_XML_IDX == MAVLINK_PRIMARY_XML_IDX
# define MAVLINK_MESSAGE_INFO {MAVLINK_MESSAGE_INFO_PX4TONUC, MAVLINK_MESSAGE_INFO_NUC_ACTION_CONT, MAVLINK_MESSAGE_INFO_NUC_MODE_CONT}
# define MAVLINK_MESSAGE_NAMES {{ "NUC_ACTION_CONT", 201 }, { "NUC_MODE_CONT", 202 }, { "PX4TONUC", 200 }}
# if MAVLINK_COMMAND_24BIT
#  include "../mavlink_get_info.h"
# endif
#endif

#ifdef __cplusplus
}
#endif // __cplusplus
#endif // MAVLINK_HT3Y_H
