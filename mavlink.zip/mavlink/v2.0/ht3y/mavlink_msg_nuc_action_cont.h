#pragma once
// MESSAGE NUC_ACTION_CONT PACKING

#define MAVLINK_MSG_ID_NUC_ACTION_CONT 201

MAVPACKED(
typedef struct __mavlink_nuc_action_cont_t {
 int64_t reserve_word; /*<  unused word*/
 int32_t altitude; /*<  the information of altitude*/
 uint16_t frame_head; /*<  the frame head of the msg (microseconds since system boot or since UNIX epoch).*/
 uint16_t frame_num; /*<   to recongize the msg*/
 uint16_t control_instruction; /*<  (see introduction 1) */
 uint16_t frame_count; /*<  0-65535*/
 uint16_t checksum; /*<    add up the data from the first place to the last place before checking, take 16 places lower  */
 uint8_t command_count; /*<  0-255 */
 uint8_t uav_num; /*<  the number of uav(px4) */
}) mavlink_nuc_action_cont_t;

#define MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN 24
#define MAVLINK_MSG_ID_NUC_ACTION_CONT_MIN_LEN 24
#define MAVLINK_MSG_ID_201_LEN 24
#define MAVLINK_MSG_ID_201_MIN_LEN 24

#define MAVLINK_MSG_ID_NUC_ACTION_CONT_CRC 173
#define MAVLINK_MSG_ID_201_CRC 173



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_NUC_ACTION_CONT { \
    201, \
    "NUC_ACTION_CONT", \
    9, \
    {  { "frame_head", NULL, MAVLINK_TYPE_UINT16_T, 0, 12, offsetof(mavlink_nuc_action_cont_t, frame_head) }, \
         { "frame_num", NULL, MAVLINK_TYPE_UINT16_T, 0, 14, offsetof(mavlink_nuc_action_cont_t, frame_num) }, \
         { "command_count", NULL, MAVLINK_TYPE_UINT8_T, 0, 22, offsetof(mavlink_nuc_action_cont_t, command_count) }, \
         { "control_instruction", NULL, MAVLINK_TYPE_UINT16_T, 0, 16, offsetof(mavlink_nuc_action_cont_t, control_instruction) }, \
         { "frame_count", NULL, MAVLINK_TYPE_UINT16_T, 0, 18, offsetof(mavlink_nuc_action_cont_t, frame_count) }, \
         { "uav_num", NULL, MAVLINK_TYPE_UINT8_T, 0, 23, offsetof(mavlink_nuc_action_cont_t, uav_num) }, \
         { "altitude", NULL, MAVLINK_TYPE_INT32_T, 0, 8, offsetof(mavlink_nuc_action_cont_t, altitude) }, \
         { "reserve_word", NULL, MAVLINK_TYPE_INT64_T, 0, 0, offsetof(mavlink_nuc_action_cont_t, reserve_word) }, \
         { "checksum", NULL, MAVLINK_TYPE_UINT16_T, 0, 20, offsetof(mavlink_nuc_action_cont_t, checksum) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_NUC_ACTION_CONT { \
    "NUC_ACTION_CONT", \
    9, \
    {  { "frame_head", NULL, MAVLINK_TYPE_UINT16_T, 0, 12, offsetof(mavlink_nuc_action_cont_t, frame_head) }, \
         { "frame_num", NULL, MAVLINK_TYPE_UINT16_T, 0, 14, offsetof(mavlink_nuc_action_cont_t, frame_num) }, \
         { "command_count", NULL, MAVLINK_TYPE_UINT8_T, 0, 22, offsetof(mavlink_nuc_action_cont_t, command_count) }, \
         { "control_instruction", NULL, MAVLINK_TYPE_UINT16_T, 0, 16, offsetof(mavlink_nuc_action_cont_t, control_instruction) }, \
         { "frame_count", NULL, MAVLINK_TYPE_UINT16_T, 0, 18, offsetof(mavlink_nuc_action_cont_t, frame_count) }, \
         { "uav_num", NULL, MAVLINK_TYPE_UINT8_T, 0, 23, offsetof(mavlink_nuc_action_cont_t, uav_num) }, \
         { "altitude", NULL, MAVLINK_TYPE_INT32_T, 0, 8, offsetof(mavlink_nuc_action_cont_t, altitude) }, \
         { "reserve_word", NULL, MAVLINK_TYPE_INT64_T, 0, 0, offsetof(mavlink_nuc_action_cont_t, reserve_word) }, \
         { "checksum", NULL, MAVLINK_TYPE_UINT16_T, 0, 20, offsetof(mavlink_nuc_action_cont_t, checksum) }, \
         } \
}
#endif

/**
 * @brief Pack a nuc_action_cont message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param frame_head  the frame head of the msg (microseconds since system boot or since UNIX epoch).
 * @param frame_num   to recongize the msg
 * @param command_count  0-255 
 * @param control_instruction  (see introduction 1) 
 * @param frame_count  0-65535
 * @param uav_num  the number of uav(px4) 
 * @param altitude  the information of altitude
 * @param reserve_word  unused word
 * @param checksum    add up the data from the first place to the last place before checking, take 16 places lower  
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_nuc_action_cont_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint16_t frame_head, uint16_t frame_num, uint8_t command_count, uint16_t control_instruction, uint16_t frame_count, uint8_t uav_num, int32_t altitude, int64_t reserve_word, uint16_t checksum)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN];
    _mav_put_int64_t(buf, 0, reserve_word);
    _mav_put_int32_t(buf, 8, altitude);
    _mav_put_uint16_t(buf, 12, frame_head);
    _mav_put_uint16_t(buf, 14, frame_num);
    _mav_put_uint16_t(buf, 16, control_instruction);
    _mav_put_uint16_t(buf, 18, frame_count);
    _mav_put_uint16_t(buf, 20, checksum);
    _mav_put_uint8_t(buf, 22, command_count);
    _mav_put_uint8_t(buf, 23, uav_num);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN);
#else
    mavlink_nuc_action_cont_t packet;
    packet.reserve_word = reserve_word;
    packet.altitude = altitude;
    packet.frame_head = frame_head;
    packet.frame_num = frame_num;
    packet.control_instruction = control_instruction;
    packet.frame_count = frame_count;
    packet.checksum = checksum;
    packet.command_count = command_count;
    packet.uav_num = uav_num;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_NUC_ACTION_CONT;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_NUC_ACTION_CONT_MIN_LEN, MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN, MAVLINK_MSG_ID_NUC_ACTION_CONT_CRC);
}

/**
 * @brief Pack a nuc_action_cont message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param frame_head  the frame head of the msg (microseconds since system boot or since UNIX epoch).
 * @param frame_num   to recongize the msg
 * @param command_count  0-255 
 * @param control_instruction  (see introduction 1) 
 * @param frame_count  0-65535
 * @param uav_num  the number of uav(px4) 
 * @param altitude  the information of altitude
 * @param reserve_word  unused word
 * @param checksum    add up the data from the first place to the last place before checking, take 16 places lower  
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_nuc_action_cont_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint16_t frame_head,uint16_t frame_num,uint8_t command_count,uint16_t control_instruction,uint16_t frame_count,uint8_t uav_num,int32_t altitude,int64_t reserve_word,uint16_t checksum)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN];
    _mav_put_int64_t(buf, 0, reserve_word);
    _mav_put_int32_t(buf, 8, altitude);
    _mav_put_uint16_t(buf, 12, frame_head);
    _mav_put_uint16_t(buf, 14, frame_num);
    _mav_put_uint16_t(buf, 16, control_instruction);
    _mav_put_uint16_t(buf, 18, frame_count);
    _mav_put_uint16_t(buf, 20, checksum);
    _mav_put_uint8_t(buf, 22, command_count);
    _mav_put_uint8_t(buf, 23, uav_num);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN);
#else
    mavlink_nuc_action_cont_t packet;
    packet.reserve_word = reserve_word;
    packet.altitude = altitude;
    packet.frame_head = frame_head;
    packet.frame_num = frame_num;
    packet.control_instruction = control_instruction;
    packet.frame_count = frame_count;
    packet.checksum = checksum;
    packet.command_count = command_count;
    packet.uav_num = uav_num;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_NUC_ACTION_CONT;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_NUC_ACTION_CONT_MIN_LEN, MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN, MAVLINK_MSG_ID_NUC_ACTION_CONT_CRC);
}

/**
 * @brief Encode a nuc_action_cont struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param nuc_action_cont C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_nuc_action_cont_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_nuc_action_cont_t* nuc_action_cont)
{
    return mavlink_msg_nuc_action_cont_pack(system_id, component_id, msg, nuc_action_cont->frame_head, nuc_action_cont->frame_num, nuc_action_cont->command_count, nuc_action_cont->control_instruction, nuc_action_cont->frame_count, nuc_action_cont->uav_num, nuc_action_cont->altitude, nuc_action_cont->reserve_word, nuc_action_cont->checksum);
}

/**
 * @brief Encode a nuc_action_cont struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param nuc_action_cont C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_nuc_action_cont_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_nuc_action_cont_t* nuc_action_cont)
{
    return mavlink_msg_nuc_action_cont_pack_chan(system_id, component_id, chan, msg, nuc_action_cont->frame_head, nuc_action_cont->frame_num, nuc_action_cont->command_count, nuc_action_cont->control_instruction, nuc_action_cont->frame_count, nuc_action_cont->uav_num, nuc_action_cont->altitude, nuc_action_cont->reserve_word, nuc_action_cont->checksum);
}

/**
 * @brief Send a nuc_action_cont message
 * @param chan MAVLink channel to send the message
 *
 * @param frame_head  the frame head of the msg (microseconds since system boot or since UNIX epoch).
 * @param frame_num   to recongize the msg
 * @param command_count  0-255 
 * @param control_instruction  (see introduction 1) 
 * @param frame_count  0-65535
 * @param uav_num  the number of uav(px4) 
 * @param altitude  the information of altitude
 * @param reserve_word  unused word
 * @param checksum    add up the data from the first place to the last place before checking, take 16 places lower  
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_nuc_action_cont_send(mavlink_channel_t chan, uint16_t frame_head, uint16_t frame_num, uint8_t command_count, uint16_t control_instruction, uint16_t frame_count, uint8_t uav_num, int32_t altitude, int64_t reserve_word, uint16_t checksum)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN];
    _mav_put_int64_t(buf, 0, reserve_word);
    _mav_put_int32_t(buf, 8, altitude);
    _mav_put_uint16_t(buf, 12, frame_head);
    _mav_put_uint16_t(buf, 14, frame_num);
    _mav_put_uint16_t(buf, 16, control_instruction);
    _mav_put_uint16_t(buf, 18, frame_count);
    _mav_put_uint16_t(buf, 20, checksum);
    _mav_put_uint8_t(buf, 22, command_count);
    _mav_put_uint8_t(buf, 23, uav_num);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NUC_ACTION_CONT, buf, MAVLINK_MSG_ID_NUC_ACTION_CONT_MIN_LEN, MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN, MAVLINK_MSG_ID_NUC_ACTION_CONT_CRC);
#else
    mavlink_nuc_action_cont_t packet;
    packet.reserve_word = reserve_word;
    packet.altitude = altitude;
    packet.frame_head = frame_head;
    packet.frame_num = frame_num;
    packet.control_instruction = control_instruction;
    packet.frame_count = frame_count;
    packet.checksum = checksum;
    packet.command_count = command_count;
    packet.uav_num = uav_num;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NUC_ACTION_CONT, (const char *)&packet, MAVLINK_MSG_ID_NUC_ACTION_CONT_MIN_LEN, MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN, MAVLINK_MSG_ID_NUC_ACTION_CONT_CRC);
#endif
}

/**
 * @brief Send a nuc_action_cont message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_nuc_action_cont_send_struct(mavlink_channel_t chan, const mavlink_nuc_action_cont_t* nuc_action_cont)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_nuc_action_cont_send(chan, nuc_action_cont->frame_head, nuc_action_cont->frame_num, nuc_action_cont->command_count, nuc_action_cont->control_instruction, nuc_action_cont->frame_count, nuc_action_cont->uav_num, nuc_action_cont->altitude, nuc_action_cont->reserve_word, nuc_action_cont->checksum);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NUC_ACTION_CONT, (const char *)nuc_action_cont, MAVLINK_MSG_ID_NUC_ACTION_CONT_MIN_LEN, MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN, MAVLINK_MSG_ID_NUC_ACTION_CONT_CRC);
#endif
}

#if MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_nuc_action_cont_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint16_t frame_head, uint16_t frame_num, uint8_t command_count, uint16_t control_instruction, uint16_t frame_count, uint8_t uav_num, int32_t altitude, int64_t reserve_word, uint16_t checksum)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_int64_t(buf, 0, reserve_word);
    _mav_put_int32_t(buf, 8, altitude);
    _mav_put_uint16_t(buf, 12, frame_head);
    _mav_put_uint16_t(buf, 14, frame_num);
    _mav_put_uint16_t(buf, 16, control_instruction);
    _mav_put_uint16_t(buf, 18, frame_count);
    _mav_put_uint16_t(buf, 20, checksum);
    _mav_put_uint8_t(buf, 22, command_count);
    _mav_put_uint8_t(buf, 23, uav_num);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NUC_ACTION_CONT, buf, MAVLINK_MSG_ID_NUC_ACTION_CONT_MIN_LEN, MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN, MAVLINK_MSG_ID_NUC_ACTION_CONT_CRC);
#else
    mavlink_nuc_action_cont_t *packet = (mavlink_nuc_action_cont_t *)msgbuf;
    packet->reserve_word = reserve_word;
    packet->altitude = altitude;
    packet->frame_head = frame_head;
    packet->frame_num = frame_num;
    packet->control_instruction = control_instruction;
    packet->frame_count = frame_count;
    packet->checksum = checksum;
    packet->command_count = command_count;
    packet->uav_num = uav_num;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NUC_ACTION_CONT, (const char *)packet, MAVLINK_MSG_ID_NUC_ACTION_CONT_MIN_LEN, MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN, MAVLINK_MSG_ID_NUC_ACTION_CONT_CRC);
#endif
}
#endif

#endif

// MESSAGE NUC_ACTION_CONT UNPACKING


/**
 * @brief Get field frame_head from nuc_action_cont message
 *
 * @return  the frame head of the msg (microseconds since system boot or since UNIX epoch).
 */
static inline uint16_t mavlink_msg_nuc_action_cont_get_frame_head(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  12);
}

/**
 * @brief Get field frame_num from nuc_action_cont message
 *
 * @return   to recongize the msg
 */
static inline uint16_t mavlink_msg_nuc_action_cont_get_frame_num(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  14);
}

/**
 * @brief Get field command_count from nuc_action_cont message
 *
 * @return  0-255 
 */
static inline uint8_t mavlink_msg_nuc_action_cont_get_command_count(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  22);
}

/**
 * @brief Get field control_instruction from nuc_action_cont message
 *
 * @return  (see introduction 1) 
 */
static inline uint16_t mavlink_msg_nuc_action_cont_get_control_instruction(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  16);
}

/**
 * @brief Get field frame_count from nuc_action_cont message
 *
 * @return  0-65535
 */
static inline uint16_t mavlink_msg_nuc_action_cont_get_frame_count(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  18);
}

/**
 * @brief Get field uav_num from nuc_action_cont message
 *
 * @return  the number of uav(px4) 
 */
static inline uint8_t mavlink_msg_nuc_action_cont_get_uav_num(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  23);
}

/**
 * @brief Get field altitude from nuc_action_cont message
 *
 * @return  the information of altitude
 */
static inline int32_t mavlink_msg_nuc_action_cont_get_altitude(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  8);
}

/**
 * @brief Get field reserve_word from nuc_action_cont message
 *
 * @return  unused word
 */
static inline int64_t mavlink_msg_nuc_action_cont_get_reserve_word(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int64_t(msg,  0);
}

/**
 * @brief Get field checksum from nuc_action_cont message
 *
 * @return    add up the data from the first place to the last place before checking, take 16 places lower  
 */
static inline uint16_t mavlink_msg_nuc_action_cont_get_checksum(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  20);
}

/**
 * @brief Decode a nuc_action_cont message into a struct
 *
 * @param msg The message to decode
 * @param nuc_action_cont C-struct to decode the message contents into
 */
static inline void mavlink_msg_nuc_action_cont_decode(const mavlink_message_t* msg, mavlink_nuc_action_cont_t* nuc_action_cont)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    nuc_action_cont->reserve_word = mavlink_msg_nuc_action_cont_get_reserve_word(msg);
    nuc_action_cont->altitude = mavlink_msg_nuc_action_cont_get_altitude(msg);
    nuc_action_cont->frame_head = mavlink_msg_nuc_action_cont_get_frame_head(msg);
    nuc_action_cont->frame_num = mavlink_msg_nuc_action_cont_get_frame_num(msg);
    nuc_action_cont->control_instruction = mavlink_msg_nuc_action_cont_get_control_instruction(msg);
    nuc_action_cont->frame_count = mavlink_msg_nuc_action_cont_get_frame_count(msg);
    nuc_action_cont->checksum = mavlink_msg_nuc_action_cont_get_checksum(msg);
    nuc_action_cont->command_count = mavlink_msg_nuc_action_cont_get_command_count(msg);
    nuc_action_cont->uav_num = mavlink_msg_nuc_action_cont_get_uav_num(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN? msg->len : MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN;
        memset(nuc_action_cont, 0, MAVLINK_MSG_ID_NUC_ACTION_CONT_LEN);
    memcpy(nuc_action_cont, _MAV_PAYLOAD(msg), len);
#endif
}
