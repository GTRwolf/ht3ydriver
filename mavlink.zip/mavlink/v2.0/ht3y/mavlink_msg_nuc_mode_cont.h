#pragma once
// MESSAGE NUC_MODE_CONT PACKING

#define MAVLINK_MSG_ID_NUC_MODE_CONT 202

MAVPACKED(
typedef struct __mavlink_nuc_mode_cont_t {
 float param1; /*<  different mode has different meanings.(roll/speed_x/lon)*/
 float param2; /*<  (pitch/speed_y/lat)*/
 float param3; /*<  (none /speed_z/alt)*/
 float param4; /*<  (nz)*/
 float yaw; /*<  degree*/
 uint16_t frame_head; /*<  the frame head of the msg (microseconds since system boot or since UNIX epoch).*/
 uint16_t frame_num; /*<   to recongize the msg*/
 uint16_t frame_seq; /*<  0-65535*/
 int16_t tilt_of_platform; /*<  -90-90 degree */
 uint16_t checksum; /*<    add up the data from the first place to the last place before checking, take 16 places lower */
 uint8_t order_seq; /*<  0-255 */
 uint8_t control_mode; /*<   -- */
 uint8_t yaw_use; /*<   the flag indicated whether used yaw,direction of rotation, 0 clockwise, 1 anticlockwise*/
 uint8_t package_length; /*<  the length of this msg or pack  */
 uint8_t package_id; /*<  the msgid of this pack */
 uint8_t reserve_word; /*<  unused word */
}) mavlink_nuc_mode_cont_t;

#define MAVLINK_MSG_ID_NUC_MODE_CONT_LEN 36
#define MAVLINK_MSG_ID_NUC_MODE_CONT_MIN_LEN 36
#define MAVLINK_MSG_ID_202_LEN 36
#define MAVLINK_MSG_ID_202_MIN_LEN 36

#define MAVLINK_MSG_ID_NUC_MODE_CONT_CRC 96
#define MAVLINK_MSG_ID_202_CRC 96



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_NUC_MODE_CONT { \
    202, \
    "NUC_MODE_CONT", \
    16, \
    {  { "frame_head", NULL, MAVLINK_TYPE_UINT16_T, 0, 20, offsetof(mavlink_nuc_mode_cont_t, frame_head) }, \
         { "frame_num", NULL, MAVLINK_TYPE_UINT16_T, 0, 22, offsetof(mavlink_nuc_mode_cont_t, frame_num) }, \
         { "order_seq", NULL, MAVLINK_TYPE_UINT8_T, 0, 30, offsetof(mavlink_nuc_mode_cont_t, order_seq) }, \
         { "frame_seq", NULL, MAVLINK_TYPE_UINT16_T, 0, 24, offsetof(mavlink_nuc_mode_cont_t, frame_seq) }, \
         { "control_mode", NULL, MAVLINK_TYPE_UINT8_T, 0, 31, offsetof(mavlink_nuc_mode_cont_t, control_mode) }, \
         { "param1", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_nuc_mode_cont_t, param1) }, \
         { "param2", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_nuc_mode_cont_t, param2) }, \
         { "param3", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_nuc_mode_cont_t, param3) }, \
         { "param4", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_nuc_mode_cont_t, param4) }, \
         { "yaw", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_nuc_mode_cont_t, yaw) }, \
         { "yaw_use", NULL, MAVLINK_TYPE_UINT8_T, 0, 32, offsetof(mavlink_nuc_mode_cont_t, yaw_use) }, \
         { "tilt_of_platform", NULL, MAVLINK_TYPE_INT16_T, 0, 26, offsetof(mavlink_nuc_mode_cont_t, tilt_of_platform) }, \
         { "package_length", NULL, MAVLINK_TYPE_UINT8_T, 0, 33, offsetof(mavlink_nuc_mode_cont_t, package_length) }, \
         { "package_id", NULL, MAVLINK_TYPE_UINT8_T, 0, 34, offsetof(mavlink_nuc_mode_cont_t, package_id) }, \
         { "reserve_word", NULL, MAVLINK_TYPE_UINT8_T, 0, 35, offsetof(mavlink_nuc_mode_cont_t, reserve_word) }, \
         { "checksum", NULL, MAVLINK_TYPE_UINT16_T, 0, 28, offsetof(mavlink_nuc_mode_cont_t, checksum) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_NUC_MODE_CONT { \
    "NUC_MODE_CONT", \
    16, \
    {  { "frame_head", NULL, MAVLINK_TYPE_UINT16_T, 0, 20, offsetof(mavlink_nuc_mode_cont_t, frame_head) }, \
         { "frame_num", NULL, MAVLINK_TYPE_UINT16_T, 0, 22, offsetof(mavlink_nuc_mode_cont_t, frame_num) }, \
         { "order_seq", NULL, MAVLINK_TYPE_UINT8_T, 0, 30, offsetof(mavlink_nuc_mode_cont_t, order_seq) }, \
         { "frame_seq", NULL, MAVLINK_TYPE_UINT16_T, 0, 24, offsetof(mavlink_nuc_mode_cont_t, frame_seq) }, \
         { "control_mode", NULL, MAVLINK_TYPE_UINT8_T, 0, 31, offsetof(mavlink_nuc_mode_cont_t, control_mode) }, \
         { "param1", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_nuc_mode_cont_t, param1) }, \
         { "param2", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_nuc_mode_cont_t, param2) }, \
         { "param3", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_nuc_mode_cont_t, param3) }, \
         { "param4", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_nuc_mode_cont_t, param4) }, \
         { "yaw", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_nuc_mode_cont_t, yaw) }, \
         { "yaw_use", NULL, MAVLINK_TYPE_UINT8_T, 0, 32, offsetof(mavlink_nuc_mode_cont_t, yaw_use) }, \
         { "tilt_of_platform", NULL, MAVLINK_TYPE_INT16_T, 0, 26, offsetof(mavlink_nuc_mode_cont_t, tilt_of_platform) }, \
         { "package_length", NULL, MAVLINK_TYPE_UINT8_T, 0, 33, offsetof(mavlink_nuc_mode_cont_t, package_length) }, \
         { "package_id", NULL, MAVLINK_TYPE_UINT8_T, 0, 34, offsetof(mavlink_nuc_mode_cont_t, package_id) }, \
         { "reserve_word", NULL, MAVLINK_TYPE_UINT8_T, 0, 35, offsetof(mavlink_nuc_mode_cont_t, reserve_word) }, \
         { "checksum", NULL, MAVLINK_TYPE_UINT16_T, 0, 28, offsetof(mavlink_nuc_mode_cont_t, checksum) }, \
         } \
}
#endif

/**
 * @brief Pack a nuc_mode_cont message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param frame_head  the frame head of the msg (microseconds since system boot or since UNIX epoch).
 * @param frame_num   to recongize the msg
 * @param order_seq  0-255 
 * @param frame_seq  0-65535
 * @param control_mode   -- 
 * @param param1  different mode has different meanings.(roll/speed_x/lon)
 * @param param2  (pitch/speed_y/lat)
 * @param param3  (none /speed_z/alt)
 * @param param4  (nz)
 * @param yaw  degree
 * @param yaw_use   the flag indicated whether used yaw,direction of rotation, 0 clockwise, 1 anticlockwise
 * @param tilt_of_platform  -90-90 degree 
 * @param package_length  the length of this msg or pack  
 * @param package_id  the msgid of this pack 
 * @param reserve_word  unused word 
 * @param checksum    add up the data from the first place to the last place before checking, take 16 places lower 
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_nuc_mode_cont_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint16_t frame_head, uint16_t frame_num, uint8_t order_seq, uint16_t frame_seq, uint8_t control_mode, float param1, float param2, float param3, float param4, float yaw, uint8_t yaw_use, int16_t tilt_of_platform, uint8_t package_length, uint8_t package_id, uint8_t reserve_word, uint16_t checksum)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_NUC_MODE_CONT_LEN];
    _mav_put_float(buf, 0, param1);
    _mav_put_float(buf, 4, param2);
    _mav_put_float(buf, 8, param3);
    _mav_put_float(buf, 12, param4);
    _mav_put_float(buf, 16, yaw);
    _mav_put_uint16_t(buf, 20, frame_head);
    _mav_put_uint16_t(buf, 22, frame_num);
    _mav_put_uint16_t(buf, 24, frame_seq);
    _mav_put_int16_t(buf, 26, tilt_of_platform);
    _mav_put_uint16_t(buf, 28, checksum);
    _mav_put_uint8_t(buf, 30, order_seq);
    _mav_put_uint8_t(buf, 31, control_mode);
    _mav_put_uint8_t(buf, 32, yaw_use);
    _mav_put_uint8_t(buf, 33, package_length);
    _mav_put_uint8_t(buf, 34, package_id);
    _mav_put_uint8_t(buf, 35, reserve_word);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_NUC_MODE_CONT_LEN);
#else
    mavlink_nuc_mode_cont_t packet;
    packet.param1 = param1;
    packet.param2 = param2;
    packet.param3 = param3;
    packet.param4 = param4;
    packet.yaw = yaw;
    packet.frame_head = frame_head;
    packet.frame_num = frame_num;
    packet.frame_seq = frame_seq;
    packet.tilt_of_platform = tilt_of_platform;
    packet.checksum = checksum;
    packet.order_seq = order_seq;
    packet.control_mode = control_mode;
    packet.yaw_use = yaw_use;
    packet.package_length = package_length;
    packet.package_id = package_id;
    packet.reserve_word = reserve_word;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_NUC_MODE_CONT_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_NUC_MODE_CONT;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_NUC_MODE_CONT_MIN_LEN, MAVLINK_MSG_ID_NUC_MODE_CONT_LEN, MAVLINK_MSG_ID_NUC_MODE_CONT_CRC);
}

/**
 * @brief Pack a nuc_mode_cont message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param frame_head  the frame head of the msg (microseconds since system boot or since UNIX epoch).
 * @param frame_num   to recongize the msg
 * @param order_seq  0-255 
 * @param frame_seq  0-65535
 * @param control_mode   -- 
 * @param param1  different mode has different meanings.(roll/speed_x/lon)
 * @param param2  (pitch/speed_y/lat)
 * @param param3  (none /speed_z/alt)
 * @param param4  (nz)
 * @param yaw  degree
 * @param yaw_use   the flag indicated whether used yaw,direction of rotation, 0 clockwise, 1 anticlockwise
 * @param tilt_of_platform  -90-90 degree 
 * @param package_length  the length of this msg or pack  
 * @param package_id  the msgid of this pack 
 * @param reserve_word  unused word 
 * @param checksum    add up the data from the first place to the last place before checking, take 16 places lower 
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_nuc_mode_cont_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint16_t frame_head,uint16_t frame_num,uint8_t order_seq,uint16_t frame_seq,uint8_t control_mode,float param1,float param2,float param3,float param4,float yaw,uint8_t yaw_use,int16_t tilt_of_platform,uint8_t package_length,uint8_t package_id,uint8_t reserve_word,uint16_t checksum)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_NUC_MODE_CONT_LEN];
    _mav_put_float(buf, 0, param1);
    _mav_put_float(buf, 4, param2);
    _mav_put_float(buf, 8, param3);
    _mav_put_float(buf, 12, param4);
    _mav_put_float(buf, 16, yaw);
    _mav_put_uint16_t(buf, 20, frame_head);
    _mav_put_uint16_t(buf, 22, frame_num);
    _mav_put_uint16_t(buf, 24, frame_seq);
    _mav_put_int16_t(buf, 26, tilt_of_platform);
    _mav_put_uint16_t(buf, 28, checksum);
    _mav_put_uint8_t(buf, 30, order_seq);
    _mav_put_uint8_t(buf, 31, control_mode);
    _mav_put_uint8_t(buf, 32, yaw_use);
    _mav_put_uint8_t(buf, 33, package_length);
    _mav_put_uint8_t(buf, 34, package_id);
    _mav_put_uint8_t(buf, 35, reserve_word);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_NUC_MODE_CONT_LEN);
#else
    mavlink_nuc_mode_cont_t packet;
    packet.param1 = param1;
    packet.param2 = param2;
    packet.param3 = param3;
    packet.param4 = param4;
    packet.yaw = yaw;
    packet.frame_head = frame_head;
    packet.frame_num = frame_num;
    packet.frame_seq = frame_seq;
    packet.tilt_of_platform = tilt_of_platform;
    packet.checksum = checksum;
    packet.order_seq = order_seq;
    packet.control_mode = control_mode;
    packet.yaw_use = yaw_use;
    packet.package_length = package_length;
    packet.package_id = package_id;
    packet.reserve_word = reserve_word;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_NUC_MODE_CONT_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_NUC_MODE_CONT;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_NUC_MODE_CONT_MIN_LEN, MAVLINK_MSG_ID_NUC_MODE_CONT_LEN, MAVLINK_MSG_ID_NUC_MODE_CONT_CRC);
}

/**
 * @brief Encode a nuc_mode_cont struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param nuc_mode_cont C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_nuc_mode_cont_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_nuc_mode_cont_t* nuc_mode_cont)
{
    return mavlink_msg_nuc_mode_cont_pack(system_id, component_id, msg, nuc_mode_cont->frame_head, nuc_mode_cont->frame_num, nuc_mode_cont->order_seq, nuc_mode_cont->frame_seq, nuc_mode_cont->control_mode, nuc_mode_cont->param1, nuc_mode_cont->param2, nuc_mode_cont->param3, nuc_mode_cont->param4, nuc_mode_cont->yaw, nuc_mode_cont->yaw_use, nuc_mode_cont->tilt_of_platform, nuc_mode_cont->package_length, nuc_mode_cont->package_id, nuc_mode_cont->reserve_word, nuc_mode_cont->checksum);
}

/**
 * @brief Encode a nuc_mode_cont struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param nuc_mode_cont C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_nuc_mode_cont_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_nuc_mode_cont_t* nuc_mode_cont)
{
    return mavlink_msg_nuc_mode_cont_pack_chan(system_id, component_id, chan, msg, nuc_mode_cont->frame_head, nuc_mode_cont->frame_num, nuc_mode_cont->order_seq, nuc_mode_cont->frame_seq, nuc_mode_cont->control_mode, nuc_mode_cont->param1, nuc_mode_cont->param2, nuc_mode_cont->param3, nuc_mode_cont->param4, nuc_mode_cont->yaw, nuc_mode_cont->yaw_use, nuc_mode_cont->tilt_of_platform, nuc_mode_cont->package_length, nuc_mode_cont->package_id, nuc_mode_cont->reserve_word, nuc_mode_cont->checksum);
}

/**
 * @brief Send a nuc_mode_cont message
 * @param chan MAVLink channel to send the message
 *
 * @param frame_head  the frame head of the msg (microseconds since system boot or since UNIX epoch).
 * @param frame_num   to recongize the msg
 * @param order_seq  0-255 
 * @param frame_seq  0-65535
 * @param control_mode   -- 
 * @param param1  different mode has different meanings.(roll/speed_x/lon)
 * @param param2  (pitch/speed_y/lat)
 * @param param3  (none /speed_z/alt)
 * @param param4  (nz)
 * @param yaw  degree
 * @param yaw_use   the flag indicated whether used yaw,direction of rotation, 0 clockwise, 1 anticlockwise
 * @param tilt_of_platform  -90-90 degree 
 * @param package_length  the length of this msg or pack  
 * @param package_id  the msgid of this pack 
 * @param reserve_word  unused word 
 * @param checksum    add up the data from the first place to the last place before checking, take 16 places lower 
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_nuc_mode_cont_send(mavlink_channel_t chan, uint16_t frame_head, uint16_t frame_num, uint8_t order_seq, uint16_t frame_seq, uint8_t control_mode, float param1, float param2, float param3, float param4, float yaw, uint8_t yaw_use, int16_t tilt_of_platform, uint8_t package_length, uint8_t package_id, uint8_t reserve_word, uint16_t checksum)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_NUC_MODE_CONT_LEN];
    _mav_put_float(buf, 0, param1);
    _mav_put_float(buf, 4, param2);
    _mav_put_float(buf, 8, param3);
    _mav_put_float(buf, 12, param4);
    _mav_put_float(buf, 16, yaw);
    _mav_put_uint16_t(buf, 20, frame_head);
    _mav_put_uint16_t(buf, 22, frame_num);
    _mav_put_uint16_t(buf, 24, frame_seq);
    _mav_put_int16_t(buf, 26, tilt_of_platform);
    _mav_put_uint16_t(buf, 28, checksum);
    _mav_put_uint8_t(buf, 30, order_seq);
    _mav_put_uint8_t(buf, 31, control_mode);
    _mav_put_uint8_t(buf, 32, yaw_use);
    _mav_put_uint8_t(buf, 33, package_length);
    _mav_put_uint8_t(buf, 34, package_id);
    _mav_put_uint8_t(buf, 35, reserve_word);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NUC_MODE_CONT, buf, MAVLINK_MSG_ID_NUC_MODE_CONT_MIN_LEN, MAVLINK_MSG_ID_NUC_MODE_CONT_LEN, MAVLINK_MSG_ID_NUC_MODE_CONT_CRC);
#else
    mavlink_nuc_mode_cont_t packet;
    packet.param1 = param1;
    packet.param2 = param2;
    packet.param3 = param3;
    packet.param4 = param4;
    packet.yaw = yaw;
    packet.frame_head = frame_head;
    packet.frame_num = frame_num;
    packet.frame_seq = frame_seq;
    packet.tilt_of_platform = tilt_of_platform;
    packet.checksum = checksum;
    packet.order_seq = order_seq;
    packet.control_mode = control_mode;
    packet.yaw_use = yaw_use;
    packet.package_length = package_length;
    packet.package_id = package_id;
    packet.reserve_word = reserve_word;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NUC_MODE_CONT, (const char *)&packet, MAVLINK_MSG_ID_NUC_MODE_CONT_MIN_LEN, MAVLINK_MSG_ID_NUC_MODE_CONT_LEN, MAVLINK_MSG_ID_NUC_MODE_CONT_CRC);
#endif
}

/**
 * @brief Send a nuc_mode_cont message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_nuc_mode_cont_send_struct(mavlink_channel_t chan, const mavlink_nuc_mode_cont_t* nuc_mode_cont)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_nuc_mode_cont_send(chan, nuc_mode_cont->frame_head, nuc_mode_cont->frame_num, nuc_mode_cont->order_seq, nuc_mode_cont->frame_seq, nuc_mode_cont->control_mode, nuc_mode_cont->param1, nuc_mode_cont->param2, nuc_mode_cont->param3, nuc_mode_cont->param4, nuc_mode_cont->yaw, nuc_mode_cont->yaw_use, nuc_mode_cont->tilt_of_platform, nuc_mode_cont->package_length, nuc_mode_cont->package_id, nuc_mode_cont->reserve_word, nuc_mode_cont->checksum);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NUC_MODE_CONT, (const char *)nuc_mode_cont, MAVLINK_MSG_ID_NUC_MODE_CONT_MIN_LEN, MAVLINK_MSG_ID_NUC_MODE_CONT_LEN, MAVLINK_MSG_ID_NUC_MODE_CONT_CRC);
#endif
}

#if MAVLINK_MSG_ID_NUC_MODE_CONT_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_nuc_mode_cont_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint16_t frame_head, uint16_t frame_num, uint8_t order_seq, uint16_t frame_seq, uint8_t control_mode, float param1, float param2, float param3, float param4, float yaw, uint8_t yaw_use, int16_t tilt_of_platform, uint8_t package_length, uint8_t package_id, uint8_t reserve_word, uint16_t checksum)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_float(buf, 0, param1);
    _mav_put_float(buf, 4, param2);
    _mav_put_float(buf, 8, param3);
    _mav_put_float(buf, 12, param4);
    _mav_put_float(buf, 16, yaw);
    _mav_put_uint16_t(buf, 20, frame_head);
    _mav_put_uint16_t(buf, 22, frame_num);
    _mav_put_uint16_t(buf, 24, frame_seq);
    _mav_put_int16_t(buf, 26, tilt_of_platform);
    _mav_put_uint16_t(buf, 28, checksum);
    _mav_put_uint8_t(buf, 30, order_seq);
    _mav_put_uint8_t(buf, 31, control_mode);
    _mav_put_uint8_t(buf, 32, yaw_use);
    _mav_put_uint8_t(buf, 33, package_length);
    _mav_put_uint8_t(buf, 34, package_id);
    _mav_put_uint8_t(buf, 35, reserve_word);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NUC_MODE_CONT, buf, MAVLINK_MSG_ID_NUC_MODE_CONT_MIN_LEN, MAVLINK_MSG_ID_NUC_MODE_CONT_LEN, MAVLINK_MSG_ID_NUC_MODE_CONT_CRC);
#else
    mavlink_nuc_mode_cont_t *packet = (mavlink_nuc_mode_cont_t *)msgbuf;
    packet->param1 = param1;
    packet->param2 = param2;
    packet->param3 = param3;
    packet->param4 = param4;
    packet->yaw = yaw;
    packet->frame_head = frame_head;
    packet->frame_num = frame_num;
    packet->frame_seq = frame_seq;
    packet->tilt_of_platform = tilt_of_platform;
    packet->checksum = checksum;
    packet->order_seq = order_seq;
    packet->control_mode = control_mode;
    packet->yaw_use = yaw_use;
    packet->package_length = package_length;
    packet->package_id = package_id;
    packet->reserve_word = reserve_word;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_NUC_MODE_CONT, (const char *)packet, MAVLINK_MSG_ID_NUC_MODE_CONT_MIN_LEN, MAVLINK_MSG_ID_NUC_MODE_CONT_LEN, MAVLINK_MSG_ID_NUC_MODE_CONT_CRC);
#endif
}
#endif

#endif

// MESSAGE NUC_MODE_CONT UNPACKING


/**
 * @brief Get field frame_head from nuc_mode_cont message
 *
 * @return  the frame head of the msg (microseconds since system boot or since UNIX epoch).
 */
static inline uint16_t mavlink_msg_nuc_mode_cont_get_frame_head(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  20);
}

/**
 * @brief Get field frame_num from nuc_mode_cont message
 *
 * @return   to recongize the msg
 */
static inline uint16_t mavlink_msg_nuc_mode_cont_get_frame_num(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  22);
}

/**
 * @brief Get field order_seq from nuc_mode_cont message
 *
 * @return  0-255 
 */
static inline uint8_t mavlink_msg_nuc_mode_cont_get_order_seq(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  30);
}

/**
 * @brief Get field frame_seq from nuc_mode_cont message
 *
 * @return  0-65535
 */
static inline uint16_t mavlink_msg_nuc_mode_cont_get_frame_seq(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  24);
}

/**
 * @brief Get field control_mode from nuc_mode_cont message
 *
 * @return   -- 
 */
static inline uint8_t mavlink_msg_nuc_mode_cont_get_control_mode(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  31);
}

/**
 * @brief Get field param1 from nuc_mode_cont message
 *
 * @return  different mode has different meanings.(roll/speed_x/lon)
 */
static inline float mavlink_msg_nuc_mode_cont_get_param1(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  0);
}

/**
 * @brief Get field param2 from nuc_mode_cont message
 *
 * @return  (pitch/speed_y/lat)
 */
static inline float mavlink_msg_nuc_mode_cont_get_param2(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  4);
}

/**
 * @brief Get field param3 from nuc_mode_cont message
 *
 * @return  (none /speed_z/alt)
 */
static inline float mavlink_msg_nuc_mode_cont_get_param3(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  8);
}

/**
 * @brief Get field param4 from nuc_mode_cont message
 *
 * @return  (nz)
 */
static inline float mavlink_msg_nuc_mode_cont_get_param4(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  12);
}

/**
 * @brief Get field yaw from nuc_mode_cont message
 *
 * @return  degree
 */
static inline float mavlink_msg_nuc_mode_cont_get_yaw(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  16);
}

/**
 * @brief Get field yaw_use from nuc_mode_cont message
 *
 * @return   the flag indicated whether used yaw,direction of rotation, 0 clockwise, 1 anticlockwise
 */
static inline uint8_t mavlink_msg_nuc_mode_cont_get_yaw_use(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  32);
}

/**
 * @brief Get field tilt_of_platform from nuc_mode_cont message
 *
 * @return  -90-90 degree 
 */
static inline int16_t mavlink_msg_nuc_mode_cont_get_tilt_of_platform(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  26);
}

/**
 * @brief Get field package_length from nuc_mode_cont message
 *
 * @return  the length of this msg or pack  
 */
static inline uint8_t mavlink_msg_nuc_mode_cont_get_package_length(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  33);
}

/**
 * @brief Get field package_id from nuc_mode_cont message
 *
 * @return  the msgid of this pack 
 */
static inline uint8_t mavlink_msg_nuc_mode_cont_get_package_id(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  34);
}

/**
 * @brief Get field reserve_word from nuc_mode_cont message
 *
 * @return  unused word 
 */
static inline uint8_t mavlink_msg_nuc_mode_cont_get_reserve_word(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  35);
}

/**
 * @brief Get field checksum from nuc_mode_cont message
 *
 * @return    add up the data from the first place to the last place before checking, take 16 places lower 
 */
static inline uint16_t mavlink_msg_nuc_mode_cont_get_checksum(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  28);
}

/**
 * @brief Decode a nuc_mode_cont message into a struct
 *
 * @param msg The message to decode
 * @param nuc_mode_cont C-struct to decode the message contents into
 */
static inline void mavlink_msg_nuc_mode_cont_decode(const mavlink_message_t* msg, mavlink_nuc_mode_cont_t* nuc_mode_cont)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    nuc_mode_cont->param1 = mavlink_msg_nuc_mode_cont_get_param1(msg);
    nuc_mode_cont->param2 = mavlink_msg_nuc_mode_cont_get_param2(msg);
    nuc_mode_cont->param3 = mavlink_msg_nuc_mode_cont_get_param3(msg);
    nuc_mode_cont->param4 = mavlink_msg_nuc_mode_cont_get_param4(msg);
    nuc_mode_cont->yaw = mavlink_msg_nuc_mode_cont_get_yaw(msg);
    nuc_mode_cont->frame_head = mavlink_msg_nuc_mode_cont_get_frame_head(msg);
    nuc_mode_cont->frame_num = mavlink_msg_nuc_mode_cont_get_frame_num(msg);
    nuc_mode_cont->frame_seq = mavlink_msg_nuc_mode_cont_get_frame_seq(msg);
    nuc_mode_cont->tilt_of_platform = mavlink_msg_nuc_mode_cont_get_tilt_of_platform(msg);
    nuc_mode_cont->checksum = mavlink_msg_nuc_mode_cont_get_checksum(msg);
    nuc_mode_cont->order_seq = mavlink_msg_nuc_mode_cont_get_order_seq(msg);
    nuc_mode_cont->control_mode = mavlink_msg_nuc_mode_cont_get_control_mode(msg);
    nuc_mode_cont->yaw_use = mavlink_msg_nuc_mode_cont_get_yaw_use(msg);
    nuc_mode_cont->package_length = mavlink_msg_nuc_mode_cont_get_package_length(msg);
    nuc_mode_cont->package_id = mavlink_msg_nuc_mode_cont_get_package_id(msg);
    nuc_mode_cont->reserve_word = mavlink_msg_nuc_mode_cont_get_reserve_word(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_NUC_MODE_CONT_LEN? msg->len : MAVLINK_MSG_ID_NUC_MODE_CONT_LEN;
        memset(nuc_mode_cont, 0, MAVLINK_MSG_ID_NUC_MODE_CONT_LEN);
    memcpy(nuc_mode_cont, _MAV_PAYLOAD(msg), len);
#endif
}
