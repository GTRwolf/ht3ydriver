// MESSAGE PX4TONUC support class

#pragma once

namespace mavlink {
namespace ht3y {
namespace msg {

/**
 * @brief PX4TONUC message
 *
 * HTSY need the msg which px4 sends to NUC 
 */
struct PX4TONUC : mavlink::Message {
    static constexpr msgid_t MSG_ID = 200;
    static constexpr size_t LENGTH = 110;
    static constexpr size_t MIN_LENGTH = 110;
    static constexpr uint8_t CRC_EXTRA = 80;
    static constexpr auto NAME = "PX4TONUC";


    uint16_t frame_head; /*<  the frame head of the msg (microseconds since system boot or since UNIX epoch). */
    uint16_t frame_num; /*<   to recongize the msg */
    uint16_t frame_count; /*<  0-65535  */
    uint16_t plane_status; /*<  to be configured by ourselves when needed(see introduction 2)  */
    uint8_t instruction_status; /*<  to implicated whether the instruction is done(0 perfers to completed, 1 perfers to not) */
    uint8_t waypoint_upload_flag; /*<  Waypoint upload flag:0-free|1-successful|2-defeat   */
    int32_t n_pos; /*<  Northward position */
    int32_t e_pos; /*<  Eastward position */
    int32_t fus_het; /*<  Fusion height  */
    int32_t n_v; /*<  Northward velocity */
    int32_t e_v; /*<  Eastward velocity */
    int32_t v_v; /*<  vertical velocity */
    int16_t pitch; /*<  pitch  */
    int16_t roll; /*<   roll  */
    int16_t yaw; /*<    yaw  */
    int32_t lon; /*<  longitude  */
    int32_t lat; /*<  latitude  */
    int64_t utc; /*<  utc  */
    uint8_t satellite_used; /*<  satellite used  */
    uint8_t gps_fix_type; /*<  fix_type (see vehicle_gps_position)  */
    uint8_t check_flag; /*<  the flag implicating whether it finished self-check  */
    uint16_t selfcheck_status; /*<  Different data bits represent different states  */
    int32_t tilt_of_platform; /*<    Tilt of platform, when use camera platform  */
    uint8_t Throwing_state; /*<    0 prefers to do not throw,while 1 prefers to do   */
    uint8_t work_finish_flag; /*<    0 prefers to do not need to update, 1 prefers to can update, the mission added by nuc, and px4 always returns 0 */
    uint8_t control_mode; /*<    40/41/42 angle controlling mode/Speed control mode/Position mode control  */
    int32_t barometric_altitude; /*<    Barometric altitude  */
    int32_t radar_altitude; /*<    Radar altitude  */
    int32_t acceleration_height; /*<    Acceleration Height  */
    int32_t satellite_altitude; /*<    Satellite altitude  */
    int16_t x_axis_acceleration; /*<   X_axis_acceleration short */
    int16_t y_axis_acceleration; /*<   y_axis_acceleration short */
    int16_t z_axis_acceleration; /*<   z_axis_acceleration short */
    int16_t x_axis_angula_velocity; /*<   x-axis angular velocity short */
    int16_t y_axis_angula_velocity; /*<   y-axis angular velocity short */
    int16_t z_axis_angula_velocity; /*<   z-axis angular velocity short */
    int16_t airspeed; /*<   cm/s */
    uint64_t reserve_word1; /*<   unused word  */
    uint16_t reserve_word2; /*<   unused word  */
    uint16_t checksum; /*<    add up the data from the first place to the last place before checking, take 16 places lower  */


    inline std::string get_name(void) const override
    {
            return NAME;
    }

    inline Info get_message_info(void) const override
    {
            return { MSG_ID, LENGTH, MIN_LENGTH, CRC_EXTRA };
    }

    inline std::string to_yaml(void) const override
    {
        std::stringstream ss;

        ss << NAME << ":" << std::endl;
        ss << "  frame_head: " << frame_head << std::endl;
        ss << "  frame_num: " << frame_num << std::endl;
        ss << "  frame_count: " << frame_count << std::endl;
        ss << "  plane_status: " << plane_status << std::endl;
        ss << "  instruction_status: " << +instruction_status << std::endl;
        ss << "  waypoint_upload_flag: " << +waypoint_upload_flag << std::endl;
        ss << "  n_pos: " << n_pos << std::endl;
        ss << "  e_pos: " << e_pos << std::endl;
        ss << "  fus_het: " << fus_het << std::endl;
        ss << "  n_v: " << n_v << std::endl;
        ss << "  e_v: " << e_v << std::endl;
        ss << "  v_v: " << v_v << std::endl;
        ss << "  pitch: " << pitch << std::endl;
        ss << "  roll: " << roll << std::endl;
        ss << "  yaw: " << yaw << std::endl;
        ss << "  lon: " << lon << std::endl;
        ss << "  lat: " << lat << std::endl;
        ss << "  utc: " << utc << std::endl;
        ss << "  satellite_used: " << +satellite_used << std::endl;
        ss << "  gps_fix_type: " << +gps_fix_type << std::endl;
        ss << "  check_flag: " << +check_flag << std::endl;
        ss << "  selfcheck_status: " << selfcheck_status << std::endl;
        ss << "  tilt_of_platform: " << tilt_of_platform << std::endl;
        ss << "  Throwing_state: " << +Throwing_state << std::endl;
        ss << "  work_finish_flag: " << +work_finish_flag << std::endl;
        ss << "  control_mode: " << +control_mode << std::endl;
        ss << "  barometric_altitude: " << barometric_altitude << std::endl;
        ss << "  radar_altitude: " << radar_altitude << std::endl;
        ss << "  acceleration_height: " << acceleration_height << std::endl;
        ss << "  satellite_altitude: " << satellite_altitude << std::endl;
        ss << "  x_axis_acceleration: " << x_axis_acceleration << std::endl;
        ss << "  y_axis_acceleration: " << y_axis_acceleration << std::endl;
        ss << "  z_axis_acceleration: " << z_axis_acceleration << std::endl;
        ss << "  x_axis_angula_velocity: " << x_axis_angula_velocity << std::endl;
        ss << "  y_axis_angula_velocity: " << y_axis_angula_velocity << std::endl;
        ss << "  z_axis_angula_velocity: " << z_axis_angula_velocity << std::endl;
        ss << "  airspeed: " << airspeed << std::endl;
        ss << "  reserve_word1: " << reserve_word1 << std::endl;
        ss << "  reserve_word2: " << reserve_word2 << std::endl;
        ss << "  checksum: " << checksum << std::endl;

        return ss.str();
    }

    inline void serialize(mavlink::MsgMap &map) const override
    {
        map.reset(MSG_ID, LENGTH);

        map << utc;                           // offset: 0
        map << reserve_word1;                 // offset: 8
        map << n_pos;                         // offset: 16
        map << e_pos;                         // offset: 20
        map << fus_het;                       // offset: 24
        map << n_v;                           // offset: 28
        map << e_v;                           // offset: 32
        map << v_v;                           // offset: 36
        map << lon;                           // offset: 40
        map << lat;                           // offset: 44
        map << tilt_of_platform;              // offset: 48
        map << barometric_altitude;           // offset: 52
        map << radar_altitude;                // offset: 56
        map << acceleration_height;           // offset: 60
        map << satellite_altitude;            // offset: 64
        map << frame_head;                    // offset: 68
        map << frame_num;                     // offset: 70
        map << frame_count;                   // offset: 72
        map << plane_status;                  // offset: 74
        map << pitch;                         // offset: 76
        map << roll;                          // offset: 78
        map << yaw;                           // offset: 80
        map << selfcheck_status;              // offset: 82
        map << x_axis_acceleration;           // offset: 84
        map << y_axis_acceleration;           // offset: 86
        map << z_axis_acceleration;           // offset: 88
        map << x_axis_angula_velocity;        // offset: 90
        map << y_axis_angula_velocity;        // offset: 92
        map << z_axis_angula_velocity;        // offset: 94
        map << airspeed;                      // offset: 96
        map << reserve_word2;                 // offset: 98
        map << checksum;                      // offset: 100
        map << instruction_status;            // offset: 102
        map << waypoint_upload_flag;          // offset: 103
        map << satellite_used;                // offset: 104
        map << gps_fix_type;                  // offset: 105
        map << check_flag;                    // offset: 106
        map << Throwing_state;                // offset: 107
        map << work_finish_flag;              // offset: 108
        map << control_mode;                  // offset: 109
    }

    inline void deserialize(mavlink::MsgMap &map) override
    {
        map >> utc;                           // offset: 0
        map >> reserve_word1;                 // offset: 8
        map >> n_pos;                         // offset: 16
        map >> e_pos;                         // offset: 20
        map >> fus_het;                       // offset: 24
        map >> n_v;                           // offset: 28
        map >> e_v;                           // offset: 32
        map >> v_v;                           // offset: 36
        map >> lon;                           // offset: 40
        map >> lat;                           // offset: 44
        map >> tilt_of_platform;              // offset: 48
        map >> barometric_altitude;           // offset: 52
        map >> radar_altitude;                // offset: 56
        map >> acceleration_height;           // offset: 60
        map >> satellite_altitude;            // offset: 64
        map >> frame_head;                    // offset: 68
        map >> frame_num;                     // offset: 70
        map >> frame_count;                   // offset: 72
        map >> plane_status;                  // offset: 74
        map >> pitch;                         // offset: 76
        map >> roll;                          // offset: 78
        map >> yaw;                           // offset: 80
        map >> selfcheck_status;              // offset: 82
        map >> x_axis_acceleration;           // offset: 84
        map >> y_axis_acceleration;           // offset: 86
        map >> z_axis_acceleration;           // offset: 88
        map >> x_axis_angula_velocity;        // offset: 90
        map >> y_axis_angula_velocity;        // offset: 92
        map >> z_axis_angula_velocity;        // offset: 94
        map >> airspeed;                      // offset: 96
        map >> reserve_word2;                 // offset: 98
        map >> checksum;                      // offset: 100
        map >> instruction_status;            // offset: 102
        map >> waypoint_upload_flag;          // offset: 103
        map >> satellite_used;                // offset: 104
        map >> gps_fix_type;                  // offset: 105
        map >> check_flag;                    // offset: 106
        map >> Throwing_state;                // offset: 107
        map >> work_finish_flag;              // offset: 108
        map >> control_mode;                  // offset: 109
    }
};

} // namespace msg
} // namespace ht3y
} // namespace mavlink
