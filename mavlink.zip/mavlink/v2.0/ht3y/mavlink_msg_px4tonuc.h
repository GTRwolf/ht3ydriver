#pragma once
// MESSAGE PX4TONUC PACKING

#define MAVLINK_MSG_ID_PX4TONUC 200

MAVPACKED(
typedef struct __mavlink_px4tonuc_t {
 int64_t utc; /*<  utc */
 uint64_t reserve_word1; /*<   unused word */
 int32_t n_pos; /*<  Northward position*/
 int32_t e_pos; /*<  Eastward position*/
 int32_t fus_het; /*<  Fusion height */
 int32_t n_v; /*<  Northward velocity*/
 int32_t e_v; /*<  Eastward velocity*/
 int32_t v_v; /*<  vertical velocity*/
 int32_t lon; /*<  longitude */
 int32_t lat; /*<  latitude */
 int32_t tilt_of_platform; /*<    Tilt of platform, when use camera platform */
 int32_t barometric_altitude; /*<    Barometric altitude */
 int32_t radar_altitude; /*<    Radar altitude */
 int32_t acceleration_height; /*<    Acceleration Height */
 int32_t satellite_altitude; /*<    Satellite altitude */
 uint16_t frame_head; /*<  the frame head of the msg (microseconds since system boot or since UNIX epoch).*/
 uint16_t frame_num; /*<   to recongize the msg*/
 uint16_t frame_count; /*<  0-65535 */
 uint16_t plane_status; /*<  to be configured by ourselves when needed(see introduction 2) */
 int16_t pitch; /*<  pitch */
 int16_t roll; /*<   roll */
 int16_t yaw; /*<    yaw */
 uint16_t selfcheck_status; /*<  Different data bits represent different states */
 int16_t x_axis_acceleration; /*<   X_axis_acceleration short*/
 int16_t y_axis_acceleration; /*<   y_axis_acceleration short*/
 int16_t z_axis_acceleration; /*<   z_axis_acceleration short*/
 int16_t x_axis_angula_velocity; /*<   x-axis angular velocity short*/
 int16_t y_axis_angula_velocity; /*<   y-axis angular velocity short*/
 int16_t z_axis_angula_velocity; /*<   z-axis angular velocity short*/
 int16_t airspeed; /*<   cm/s*/
 uint16_t reserve_word2; /*<   unused word */
 uint16_t checksum; /*<    add up the data from the first place to the last place before checking, take 16 places lower */
 uint8_t instruction_status; /*<  to implicated whether the instruction is done(0 perfers to completed, 1 perfers to not)*/
 uint8_t waypoint_upload_flag; /*<  Waypoint upload flag:0-free|1-successful|2-defeat  */
 uint8_t satellite_used; /*<  satellite used */
 uint8_t gps_fix_type; /*<  fix_type (see vehicle_gps_position) */
 uint8_t check_flag; /*<  the flag implicating whether it finished self-check */
 uint8_t Throwing_state; /*<    0 prefers to do not throw,while 1 prefers to do  */
 uint8_t work_finish_flag; /*<    0 prefers to do not need to update, 1 prefers to can update, the mission added by nuc, and px4 always returns 0*/
 uint8_t control_mode; /*<    40/41/42 angle controlling mode/Speed control mode/Position mode control */
}) mavlink_px4tonuc_t;

#define MAVLINK_MSG_ID_PX4TONUC_LEN 110
#define MAVLINK_MSG_ID_PX4TONUC_MIN_LEN 110
#define MAVLINK_MSG_ID_200_LEN 110
#define MAVLINK_MSG_ID_200_MIN_LEN 110

#define MAVLINK_MSG_ID_PX4TONUC_CRC 80
#define MAVLINK_MSG_ID_200_CRC 80



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_PX4TONUC { \
    200, \
    "PX4TONUC", \
    40, \
    {  { "frame_head", NULL, MAVLINK_TYPE_UINT16_T, 0, 68, offsetof(mavlink_px4tonuc_t, frame_head) }, \
         { "frame_num", NULL, MAVLINK_TYPE_UINT16_T, 0, 70, offsetof(mavlink_px4tonuc_t, frame_num) }, \
         { "frame_count", NULL, MAVLINK_TYPE_UINT16_T, 0, 72, offsetof(mavlink_px4tonuc_t, frame_count) }, \
         { "plane_status", NULL, MAVLINK_TYPE_UINT16_T, 0, 74, offsetof(mavlink_px4tonuc_t, plane_status) }, \
         { "instruction_status", NULL, MAVLINK_TYPE_UINT8_T, 0, 102, offsetof(mavlink_px4tonuc_t, instruction_status) }, \
         { "waypoint_upload_flag", NULL, MAVLINK_TYPE_UINT8_T, 0, 103, offsetof(mavlink_px4tonuc_t, waypoint_upload_flag) }, \
         { "n_pos", NULL, MAVLINK_TYPE_INT32_T, 0, 16, offsetof(mavlink_px4tonuc_t, n_pos) }, \
         { "e_pos", NULL, MAVLINK_TYPE_INT32_T, 0, 20, offsetof(mavlink_px4tonuc_t, e_pos) }, \
         { "fus_het", NULL, MAVLINK_TYPE_INT32_T, 0, 24, offsetof(mavlink_px4tonuc_t, fus_het) }, \
         { "n_v", NULL, MAVLINK_TYPE_INT32_T, 0, 28, offsetof(mavlink_px4tonuc_t, n_v) }, \
         { "e_v", NULL, MAVLINK_TYPE_INT32_T, 0, 32, offsetof(mavlink_px4tonuc_t, e_v) }, \
         { "v_v", NULL, MAVLINK_TYPE_INT32_T, 0, 36, offsetof(mavlink_px4tonuc_t, v_v) }, \
         { "pitch", NULL, MAVLINK_TYPE_INT16_T, 0, 76, offsetof(mavlink_px4tonuc_t, pitch) }, \
         { "roll", NULL, MAVLINK_TYPE_INT16_T, 0, 78, offsetof(mavlink_px4tonuc_t, roll) }, \
         { "yaw", NULL, MAVLINK_TYPE_INT16_T, 0, 80, offsetof(mavlink_px4tonuc_t, yaw) }, \
         { "lon", NULL, MAVLINK_TYPE_INT32_T, 0, 40, offsetof(mavlink_px4tonuc_t, lon) }, \
         { "lat", NULL, MAVLINK_TYPE_INT32_T, 0, 44, offsetof(mavlink_px4tonuc_t, lat) }, \
         { "utc", NULL, MAVLINK_TYPE_INT64_T, 0, 0, offsetof(mavlink_px4tonuc_t, utc) }, \
         { "satellite_used", NULL, MAVLINK_TYPE_UINT8_T, 0, 104, offsetof(mavlink_px4tonuc_t, satellite_used) }, \
         { "gps_fix_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 105, offsetof(mavlink_px4tonuc_t, gps_fix_type) }, \
         { "check_flag", NULL, MAVLINK_TYPE_UINT8_T, 0, 106, offsetof(mavlink_px4tonuc_t, check_flag) }, \
         { "selfcheck_status", NULL, MAVLINK_TYPE_UINT16_T, 0, 82, offsetof(mavlink_px4tonuc_t, selfcheck_status) }, \
         { "tilt_of_platform", NULL, MAVLINK_TYPE_INT32_T, 0, 48, offsetof(mavlink_px4tonuc_t, tilt_of_platform) }, \
         { "Throwing_state", NULL, MAVLINK_TYPE_UINT8_T, 0, 107, offsetof(mavlink_px4tonuc_t, Throwing_state) }, \
         { "work_finish_flag", NULL, MAVLINK_TYPE_UINT8_T, 0, 108, offsetof(mavlink_px4tonuc_t, work_finish_flag) }, \
         { "control_mode", NULL, MAVLINK_TYPE_UINT8_T, 0, 109, offsetof(mavlink_px4tonuc_t, control_mode) }, \
         { "barometric_altitude", NULL, MAVLINK_TYPE_INT32_T, 0, 52, offsetof(mavlink_px4tonuc_t, barometric_altitude) }, \
         { "radar_altitude", NULL, MAVLINK_TYPE_INT32_T, 0, 56, offsetof(mavlink_px4tonuc_t, radar_altitude) }, \
         { "acceleration_height", NULL, MAVLINK_TYPE_INT32_T, 0, 60, offsetof(mavlink_px4tonuc_t, acceleration_height) }, \
         { "satellite_altitude", NULL, MAVLINK_TYPE_INT32_T, 0, 64, offsetof(mavlink_px4tonuc_t, satellite_altitude) }, \
         { "x_axis_acceleration", NULL, MAVLINK_TYPE_INT16_T, 0, 84, offsetof(mavlink_px4tonuc_t, x_axis_acceleration) }, \
         { "y_axis_acceleration", NULL, MAVLINK_TYPE_INT16_T, 0, 86, offsetof(mavlink_px4tonuc_t, y_axis_acceleration) }, \
         { "z_axis_acceleration", NULL, MAVLINK_TYPE_INT16_T, 0, 88, offsetof(mavlink_px4tonuc_t, z_axis_acceleration) }, \
         { "x_axis_angula_velocity", NULL, MAVLINK_TYPE_INT16_T, 0, 90, offsetof(mavlink_px4tonuc_t, x_axis_angula_velocity) }, \
         { "y_axis_angula_velocity", NULL, MAVLINK_TYPE_INT16_T, 0, 92, offsetof(mavlink_px4tonuc_t, y_axis_angula_velocity) }, \
         { "z_axis_angula_velocity", NULL, MAVLINK_TYPE_INT16_T, 0, 94, offsetof(mavlink_px4tonuc_t, z_axis_angula_velocity) }, \
         { "airspeed", NULL, MAVLINK_TYPE_INT16_T, 0, 96, offsetof(mavlink_px4tonuc_t, airspeed) }, \
         { "reserve_word1", NULL, MAVLINK_TYPE_UINT64_T, 0, 8, offsetof(mavlink_px4tonuc_t, reserve_word1) }, \
         { "reserve_word2", NULL, MAVLINK_TYPE_UINT16_T, 0, 98, offsetof(mavlink_px4tonuc_t, reserve_word2) }, \
         { "checksum", NULL, MAVLINK_TYPE_UINT16_T, 0, 100, offsetof(mavlink_px4tonuc_t, checksum) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_PX4TONUC { \
    "PX4TONUC", \
    40, \
    {  { "frame_head", NULL, MAVLINK_TYPE_UINT16_T, 0, 68, offsetof(mavlink_px4tonuc_t, frame_head) }, \
         { "frame_num", NULL, MAVLINK_TYPE_UINT16_T, 0, 70, offsetof(mavlink_px4tonuc_t, frame_num) }, \
         { "frame_count", NULL, MAVLINK_TYPE_UINT16_T, 0, 72, offsetof(mavlink_px4tonuc_t, frame_count) }, \
         { "plane_status", NULL, MAVLINK_TYPE_UINT16_T, 0, 74, offsetof(mavlink_px4tonuc_t, plane_status) }, \
         { "instruction_status", NULL, MAVLINK_TYPE_UINT8_T, 0, 102, offsetof(mavlink_px4tonuc_t, instruction_status) }, \
         { "waypoint_upload_flag", NULL, MAVLINK_TYPE_UINT8_T, 0, 103, offsetof(mavlink_px4tonuc_t, waypoint_upload_flag) }, \
         { "n_pos", NULL, MAVLINK_TYPE_INT32_T, 0, 16, offsetof(mavlink_px4tonuc_t, n_pos) }, \
         { "e_pos", NULL, MAVLINK_TYPE_INT32_T, 0, 20, offsetof(mavlink_px4tonuc_t, e_pos) }, \
         { "fus_het", NULL, MAVLINK_TYPE_INT32_T, 0, 24, offsetof(mavlink_px4tonuc_t, fus_het) }, \
         { "n_v", NULL, MAVLINK_TYPE_INT32_T, 0, 28, offsetof(mavlink_px4tonuc_t, n_v) }, \
         { "e_v", NULL, MAVLINK_TYPE_INT32_T, 0, 32, offsetof(mavlink_px4tonuc_t, e_v) }, \
         { "v_v", NULL, MAVLINK_TYPE_INT32_T, 0, 36, offsetof(mavlink_px4tonuc_t, v_v) }, \
         { "pitch", NULL, MAVLINK_TYPE_INT16_T, 0, 76, offsetof(mavlink_px4tonuc_t, pitch) }, \
         { "roll", NULL, MAVLINK_TYPE_INT16_T, 0, 78, offsetof(mavlink_px4tonuc_t, roll) }, \
         { "yaw", NULL, MAVLINK_TYPE_INT16_T, 0, 80, offsetof(mavlink_px4tonuc_t, yaw) }, \
         { "lon", NULL, MAVLINK_TYPE_INT32_T, 0, 40, offsetof(mavlink_px4tonuc_t, lon) }, \
         { "lat", NULL, MAVLINK_TYPE_INT32_T, 0, 44, offsetof(mavlink_px4tonuc_t, lat) }, \
         { "utc", NULL, MAVLINK_TYPE_INT64_T, 0, 0, offsetof(mavlink_px4tonuc_t, utc) }, \
         { "satellite_used", NULL, MAVLINK_TYPE_UINT8_T, 0, 104, offsetof(mavlink_px4tonuc_t, satellite_used) }, \
         { "gps_fix_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 105, offsetof(mavlink_px4tonuc_t, gps_fix_type) }, \
         { "check_flag", NULL, MAVLINK_TYPE_UINT8_T, 0, 106, offsetof(mavlink_px4tonuc_t, check_flag) }, \
         { "selfcheck_status", NULL, MAVLINK_TYPE_UINT16_T, 0, 82, offsetof(mavlink_px4tonuc_t, selfcheck_status) }, \
         { "tilt_of_platform", NULL, MAVLINK_TYPE_INT32_T, 0, 48, offsetof(mavlink_px4tonuc_t, tilt_of_platform) }, \
         { "Throwing_state", NULL, MAVLINK_TYPE_UINT8_T, 0, 107, offsetof(mavlink_px4tonuc_t, Throwing_state) }, \
         { "work_finish_flag", NULL, MAVLINK_TYPE_UINT8_T, 0, 108, offsetof(mavlink_px4tonuc_t, work_finish_flag) }, \
         { "control_mode", NULL, MAVLINK_TYPE_UINT8_T, 0, 109, offsetof(mavlink_px4tonuc_t, control_mode) }, \
         { "barometric_altitude", NULL, MAVLINK_TYPE_INT32_T, 0, 52, offsetof(mavlink_px4tonuc_t, barometric_altitude) }, \
         { "radar_altitude", NULL, MAVLINK_TYPE_INT32_T, 0, 56, offsetof(mavlink_px4tonuc_t, radar_altitude) }, \
         { "acceleration_height", NULL, MAVLINK_TYPE_INT32_T, 0, 60, offsetof(mavlink_px4tonuc_t, acceleration_height) }, \
         { "satellite_altitude", NULL, MAVLINK_TYPE_INT32_T, 0, 64, offsetof(mavlink_px4tonuc_t, satellite_altitude) }, \
         { "x_axis_acceleration", NULL, MAVLINK_TYPE_INT16_T, 0, 84, offsetof(mavlink_px4tonuc_t, x_axis_acceleration) }, \
         { "y_axis_acceleration", NULL, MAVLINK_TYPE_INT16_T, 0, 86, offsetof(mavlink_px4tonuc_t, y_axis_acceleration) }, \
         { "z_axis_acceleration", NULL, MAVLINK_TYPE_INT16_T, 0, 88, offsetof(mavlink_px4tonuc_t, z_axis_acceleration) }, \
         { "x_axis_angula_velocity", NULL, MAVLINK_TYPE_INT16_T, 0, 90, offsetof(mavlink_px4tonuc_t, x_axis_angula_velocity) }, \
         { "y_axis_angula_velocity", NULL, MAVLINK_TYPE_INT16_T, 0, 92, offsetof(mavlink_px4tonuc_t, y_axis_angula_velocity) }, \
         { "z_axis_angula_velocity", NULL, MAVLINK_TYPE_INT16_T, 0, 94, offsetof(mavlink_px4tonuc_t, z_axis_angula_velocity) }, \
         { "airspeed", NULL, MAVLINK_TYPE_INT16_T, 0, 96, offsetof(mavlink_px4tonuc_t, airspeed) }, \
         { "reserve_word1", NULL, MAVLINK_TYPE_UINT64_T, 0, 8, offsetof(mavlink_px4tonuc_t, reserve_word1) }, \
         { "reserve_word2", NULL, MAVLINK_TYPE_UINT16_T, 0, 98, offsetof(mavlink_px4tonuc_t, reserve_word2) }, \
         { "checksum", NULL, MAVLINK_TYPE_UINT16_T, 0, 100, offsetof(mavlink_px4tonuc_t, checksum) }, \
         } \
}
#endif

/**
 * @brief Pack a px4tonuc message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param frame_head  the frame head of the msg (microseconds since system boot or since UNIX epoch).
 * @param frame_num   to recongize the msg
 * @param frame_count  0-65535 
 * @param plane_status  to be configured by ourselves when needed(see introduction 2) 
 * @param instruction_status  to implicated whether the instruction is done(0 perfers to completed, 1 perfers to not)
 * @param waypoint_upload_flag  Waypoint upload flag:0-free|1-successful|2-defeat  
 * @param n_pos  Northward position
 * @param e_pos  Eastward position
 * @param fus_het  Fusion height 
 * @param n_v  Northward velocity
 * @param e_v  Eastward velocity
 * @param v_v  vertical velocity
 * @param pitch  pitch 
 * @param roll   roll 
 * @param yaw    yaw 
 * @param lon  longitude 
 * @param lat  latitude 
 * @param utc  utc 
 * @param satellite_used  satellite used 
 * @param gps_fix_type  fix_type (see vehicle_gps_position) 
 * @param check_flag  the flag implicating whether it finished self-check 
 * @param selfcheck_status  Different data bits represent different states 
 * @param tilt_of_platform    Tilt of platform, when use camera platform 
 * @param Throwing_state    0 prefers to do not throw,while 1 prefers to do  
 * @param work_finish_flag    0 prefers to do not need to update, 1 prefers to can update, the mission added by nuc, and px4 always returns 0
 * @param control_mode    40/41/42 angle controlling mode/Speed control mode/Position mode control 
 * @param barometric_altitude    Barometric altitude 
 * @param radar_altitude    Radar altitude 
 * @param acceleration_height    Acceleration Height 
 * @param satellite_altitude    Satellite altitude 
 * @param x_axis_acceleration   X_axis_acceleration short
 * @param y_axis_acceleration   y_axis_acceleration short
 * @param z_axis_acceleration   z_axis_acceleration short
 * @param x_axis_angula_velocity   x-axis angular velocity short
 * @param y_axis_angula_velocity   y-axis angular velocity short
 * @param z_axis_angula_velocity   z-axis angular velocity short
 * @param airspeed   cm/s
 * @param reserve_word1   unused word 
 * @param reserve_word2   unused word 
 * @param checksum    add up the data from the first place to the last place before checking, take 16 places lower 
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_px4tonuc_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint16_t frame_head, uint16_t frame_num, uint16_t frame_count, uint16_t plane_status, uint8_t instruction_status, uint8_t waypoint_upload_flag, int32_t n_pos, int32_t e_pos, int32_t fus_het, int32_t n_v, int32_t e_v, int32_t v_v, int16_t pitch, int16_t roll, int16_t yaw, int32_t lon, int32_t lat, int64_t utc, uint8_t satellite_used, uint8_t gps_fix_type, uint8_t check_flag, uint16_t selfcheck_status, int32_t tilt_of_platform, uint8_t Throwing_state, uint8_t work_finish_flag, uint8_t control_mode, int32_t barometric_altitude, int32_t radar_altitude, int32_t acceleration_height, int32_t satellite_altitude, int16_t x_axis_acceleration, int16_t y_axis_acceleration, int16_t z_axis_acceleration, int16_t x_axis_angula_velocity, int16_t y_axis_angula_velocity, int16_t z_axis_angula_velocity, int16_t airspeed, uint64_t reserve_word1, uint16_t reserve_word2, uint16_t checksum)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_PX4TONUC_LEN];
    _mav_put_int64_t(buf, 0, utc);
    _mav_put_uint64_t(buf, 8, reserve_word1);
    _mav_put_int32_t(buf, 16, n_pos);
    _mav_put_int32_t(buf, 20, e_pos);
    _mav_put_int32_t(buf, 24, fus_het);
    _mav_put_int32_t(buf, 28, n_v);
    _mav_put_int32_t(buf, 32, e_v);
    _mav_put_int32_t(buf, 36, v_v);
    _mav_put_int32_t(buf, 40, lon);
    _mav_put_int32_t(buf, 44, lat);
    _mav_put_int32_t(buf, 48, tilt_of_platform);
    _mav_put_int32_t(buf, 52, barometric_altitude);
    _mav_put_int32_t(buf, 56, radar_altitude);
    _mav_put_int32_t(buf, 60, acceleration_height);
    _mav_put_int32_t(buf, 64, satellite_altitude);
    _mav_put_uint16_t(buf, 68, frame_head);
    _mav_put_uint16_t(buf, 70, frame_num);
    _mav_put_uint16_t(buf, 72, frame_count);
    _mav_put_uint16_t(buf, 74, plane_status);
    _mav_put_int16_t(buf, 76, pitch);
    _mav_put_int16_t(buf, 78, roll);
    _mav_put_int16_t(buf, 80, yaw);
    _mav_put_uint16_t(buf, 82, selfcheck_status);
    _mav_put_int16_t(buf, 84, x_axis_acceleration);
    _mav_put_int16_t(buf, 86, y_axis_acceleration);
    _mav_put_int16_t(buf, 88, z_axis_acceleration);
    _mav_put_int16_t(buf, 90, x_axis_angula_velocity);
    _mav_put_int16_t(buf, 92, y_axis_angula_velocity);
    _mav_put_int16_t(buf, 94, z_axis_angula_velocity);
    _mav_put_int16_t(buf, 96, airspeed);
    _mav_put_uint16_t(buf, 98, reserve_word2);
    _mav_put_uint16_t(buf, 100, checksum);
    _mav_put_uint8_t(buf, 102, instruction_status);
    _mav_put_uint8_t(buf, 103, waypoint_upload_flag);
    _mav_put_uint8_t(buf, 104, satellite_used);
    _mav_put_uint8_t(buf, 105, gps_fix_type);
    _mav_put_uint8_t(buf, 106, check_flag);
    _mav_put_uint8_t(buf, 107, Throwing_state);
    _mav_put_uint8_t(buf, 108, work_finish_flag);
    _mav_put_uint8_t(buf, 109, control_mode);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_PX4TONUC_LEN);
#else
    mavlink_px4tonuc_t packet;
    packet.utc = utc;
    packet.reserve_word1 = reserve_word1;
    packet.n_pos = n_pos;
    packet.e_pos = e_pos;
    packet.fus_het = fus_het;
    packet.n_v = n_v;
    packet.e_v = e_v;
    packet.v_v = v_v;
    packet.lon = lon;
    packet.lat = lat;
    packet.tilt_of_platform = tilt_of_platform;
    packet.barometric_altitude = barometric_altitude;
    packet.radar_altitude = radar_altitude;
    packet.acceleration_height = acceleration_height;
    packet.satellite_altitude = satellite_altitude;
    packet.frame_head = frame_head;
    packet.frame_num = frame_num;
    packet.frame_count = frame_count;
    packet.plane_status = plane_status;
    packet.pitch = pitch;
    packet.roll = roll;
    packet.yaw = yaw;
    packet.selfcheck_status = selfcheck_status;
    packet.x_axis_acceleration = x_axis_acceleration;
    packet.y_axis_acceleration = y_axis_acceleration;
    packet.z_axis_acceleration = z_axis_acceleration;
    packet.x_axis_angula_velocity = x_axis_angula_velocity;
    packet.y_axis_angula_velocity = y_axis_angula_velocity;
    packet.z_axis_angula_velocity = z_axis_angula_velocity;
    packet.airspeed = airspeed;
    packet.reserve_word2 = reserve_word2;
    packet.checksum = checksum;
    packet.instruction_status = instruction_status;
    packet.waypoint_upload_flag = waypoint_upload_flag;
    packet.satellite_used = satellite_used;
    packet.gps_fix_type = gps_fix_type;
    packet.check_flag = check_flag;
    packet.Throwing_state = Throwing_state;
    packet.work_finish_flag = work_finish_flag;
    packet.control_mode = control_mode;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_PX4TONUC_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_PX4TONUC;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_PX4TONUC_MIN_LEN, MAVLINK_MSG_ID_PX4TONUC_LEN, MAVLINK_MSG_ID_PX4TONUC_CRC);
}

/**
 * @brief Pack a px4tonuc message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param frame_head  the frame head of the msg (microseconds since system boot or since UNIX epoch).
 * @param frame_num   to recongize the msg
 * @param frame_count  0-65535 
 * @param plane_status  to be configured by ourselves when needed(see introduction 2) 
 * @param instruction_status  to implicated whether the instruction is done(0 perfers to completed, 1 perfers to not)
 * @param waypoint_upload_flag  Waypoint upload flag:0-free|1-successful|2-defeat  
 * @param n_pos  Northward position
 * @param e_pos  Eastward position
 * @param fus_het  Fusion height 
 * @param n_v  Northward velocity
 * @param e_v  Eastward velocity
 * @param v_v  vertical velocity
 * @param pitch  pitch 
 * @param roll   roll 
 * @param yaw    yaw 
 * @param lon  longitude 
 * @param lat  latitude 
 * @param utc  utc 
 * @param satellite_used  satellite used 
 * @param gps_fix_type  fix_type (see vehicle_gps_position) 
 * @param check_flag  the flag implicating whether it finished self-check 
 * @param selfcheck_status  Different data bits represent different states 
 * @param tilt_of_platform    Tilt of platform, when use camera platform 
 * @param Throwing_state    0 prefers to do not throw,while 1 prefers to do  
 * @param work_finish_flag    0 prefers to do not need to update, 1 prefers to can update, the mission added by nuc, and px4 always returns 0
 * @param control_mode    40/41/42 angle controlling mode/Speed control mode/Position mode control 
 * @param barometric_altitude    Barometric altitude 
 * @param radar_altitude    Radar altitude 
 * @param acceleration_height    Acceleration Height 
 * @param satellite_altitude    Satellite altitude 
 * @param x_axis_acceleration   X_axis_acceleration short
 * @param y_axis_acceleration   y_axis_acceleration short
 * @param z_axis_acceleration   z_axis_acceleration short
 * @param x_axis_angula_velocity   x-axis angular velocity short
 * @param y_axis_angula_velocity   y-axis angular velocity short
 * @param z_axis_angula_velocity   z-axis angular velocity short
 * @param airspeed   cm/s
 * @param reserve_word1   unused word 
 * @param reserve_word2   unused word 
 * @param checksum    add up the data from the first place to the last place before checking, take 16 places lower 
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_px4tonuc_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint16_t frame_head,uint16_t frame_num,uint16_t frame_count,uint16_t plane_status,uint8_t instruction_status,uint8_t waypoint_upload_flag,int32_t n_pos,int32_t e_pos,int32_t fus_het,int32_t n_v,int32_t e_v,int32_t v_v,int16_t pitch,int16_t roll,int16_t yaw,int32_t lon,int32_t lat,int64_t utc,uint8_t satellite_used,uint8_t gps_fix_type,uint8_t check_flag,uint16_t selfcheck_status,int32_t tilt_of_platform,uint8_t Throwing_state,uint8_t work_finish_flag,uint8_t control_mode,int32_t barometric_altitude,int32_t radar_altitude,int32_t acceleration_height,int32_t satellite_altitude,int16_t x_axis_acceleration,int16_t y_axis_acceleration,int16_t z_axis_acceleration,int16_t x_axis_angula_velocity,int16_t y_axis_angula_velocity,int16_t z_axis_angula_velocity,int16_t airspeed,uint64_t reserve_word1,uint16_t reserve_word2,uint16_t checksum)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_PX4TONUC_LEN];
    _mav_put_int64_t(buf, 0, utc);
    _mav_put_uint64_t(buf, 8, reserve_word1);
    _mav_put_int32_t(buf, 16, n_pos);
    _mav_put_int32_t(buf, 20, e_pos);
    _mav_put_int32_t(buf, 24, fus_het);
    _mav_put_int32_t(buf, 28, n_v);
    _mav_put_int32_t(buf, 32, e_v);
    _mav_put_int32_t(buf, 36, v_v);
    _mav_put_int32_t(buf, 40, lon);
    _mav_put_int32_t(buf, 44, lat);
    _mav_put_int32_t(buf, 48, tilt_of_platform);
    _mav_put_int32_t(buf, 52, barometric_altitude);
    _mav_put_int32_t(buf, 56, radar_altitude);
    _mav_put_int32_t(buf, 60, acceleration_height);
    _mav_put_int32_t(buf, 64, satellite_altitude);
    _mav_put_uint16_t(buf, 68, frame_head);
    _mav_put_uint16_t(buf, 70, frame_num);
    _mav_put_uint16_t(buf, 72, frame_count);
    _mav_put_uint16_t(buf, 74, plane_status);
    _mav_put_int16_t(buf, 76, pitch);
    _mav_put_int16_t(buf, 78, roll);
    _mav_put_int16_t(buf, 80, yaw);
    _mav_put_uint16_t(buf, 82, selfcheck_status);
    _mav_put_int16_t(buf, 84, x_axis_acceleration);
    _mav_put_int16_t(buf, 86, y_axis_acceleration);
    _mav_put_int16_t(buf, 88, z_axis_acceleration);
    _mav_put_int16_t(buf, 90, x_axis_angula_velocity);
    _mav_put_int16_t(buf, 92, y_axis_angula_velocity);
    _mav_put_int16_t(buf, 94, z_axis_angula_velocity);
    _mav_put_int16_t(buf, 96, airspeed);
    _mav_put_uint16_t(buf, 98, reserve_word2);
    _mav_put_uint16_t(buf, 100, checksum);
    _mav_put_uint8_t(buf, 102, instruction_status);
    _mav_put_uint8_t(buf, 103, waypoint_upload_flag);
    _mav_put_uint8_t(buf, 104, satellite_used);
    _mav_put_uint8_t(buf, 105, gps_fix_type);
    _mav_put_uint8_t(buf, 106, check_flag);
    _mav_put_uint8_t(buf, 107, Throwing_state);
    _mav_put_uint8_t(buf, 108, work_finish_flag);
    _mav_put_uint8_t(buf, 109, control_mode);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_PX4TONUC_LEN);
#else
    mavlink_px4tonuc_t packet;
    packet.utc = utc;
    packet.reserve_word1 = reserve_word1;
    packet.n_pos = n_pos;
    packet.e_pos = e_pos;
    packet.fus_het = fus_het;
    packet.n_v = n_v;
    packet.e_v = e_v;
    packet.v_v = v_v;
    packet.lon = lon;
    packet.lat = lat;
    packet.tilt_of_platform = tilt_of_platform;
    packet.barometric_altitude = barometric_altitude;
    packet.radar_altitude = radar_altitude;
    packet.acceleration_height = acceleration_height;
    packet.satellite_altitude = satellite_altitude;
    packet.frame_head = frame_head;
    packet.frame_num = frame_num;
    packet.frame_count = frame_count;
    packet.plane_status = plane_status;
    packet.pitch = pitch;
    packet.roll = roll;
    packet.yaw = yaw;
    packet.selfcheck_status = selfcheck_status;
    packet.x_axis_acceleration = x_axis_acceleration;
    packet.y_axis_acceleration = y_axis_acceleration;
    packet.z_axis_acceleration = z_axis_acceleration;
    packet.x_axis_angula_velocity = x_axis_angula_velocity;
    packet.y_axis_angula_velocity = y_axis_angula_velocity;
    packet.z_axis_angula_velocity = z_axis_angula_velocity;
    packet.airspeed = airspeed;
    packet.reserve_word2 = reserve_word2;
    packet.checksum = checksum;
    packet.instruction_status = instruction_status;
    packet.waypoint_upload_flag = waypoint_upload_flag;
    packet.satellite_used = satellite_used;
    packet.gps_fix_type = gps_fix_type;
    packet.check_flag = check_flag;
    packet.Throwing_state = Throwing_state;
    packet.work_finish_flag = work_finish_flag;
    packet.control_mode = control_mode;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_PX4TONUC_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_PX4TONUC;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_PX4TONUC_MIN_LEN, MAVLINK_MSG_ID_PX4TONUC_LEN, MAVLINK_MSG_ID_PX4TONUC_CRC);
}

/**
 * @brief Encode a px4tonuc struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param px4tonuc C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_px4tonuc_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_px4tonuc_t* px4tonuc)
{
    return mavlink_msg_px4tonuc_pack(system_id, component_id, msg, px4tonuc->frame_head, px4tonuc->frame_num, px4tonuc->frame_count, px4tonuc->plane_status, px4tonuc->instruction_status, px4tonuc->waypoint_upload_flag, px4tonuc->n_pos, px4tonuc->e_pos, px4tonuc->fus_het, px4tonuc->n_v, px4tonuc->e_v, px4tonuc->v_v, px4tonuc->pitch, px4tonuc->roll, px4tonuc->yaw, px4tonuc->lon, px4tonuc->lat, px4tonuc->utc, px4tonuc->satellite_used, px4tonuc->gps_fix_type, px4tonuc->check_flag, px4tonuc->selfcheck_status, px4tonuc->tilt_of_platform, px4tonuc->Throwing_state, px4tonuc->work_finish_flag, px4tonuc->control_mode, px4tonuc->barometric_altitude, px4tonuc->radar_altitude, px4tonuc->acceleration_height, px4tonuc->satellite_altitude, px4tonuc->x_axis_acceleration, px4tonuc->y_axis_acceleration, px4tonuc->z_axis_acceleration, px4tonuc->x_axis_angula_velocity, px4tonuc->y_axis_angula_velocity, px4tonuc->z_axis_angula_velocity, px4tonuc->airspeed, px4tonuc->reserve_word1, px4tonuc->reserve_word2, px4tonuc->checksum);
}

/**
 * @brief Encode a px4tonuc struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param px4tonuc C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_px4tonuc_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_px4tonuc_t* px4tonuc)
{
    return mavlink_msg_px4tonuc_pack_chan(system_id, component_id, chan, msg, px4tonuc->frame_head, px4tonuc->frame_num, px4tonuc->frame_count, px4tonuc->plane_status, px4tonuc->instruction_status, px4tonuc->waypoint_upload_flag, px4tonuc->n_pos, px4tonuc->e_pos, px4tonuc->fus_het, px4tonuc->n_v, px4tonuc->e_v, px4tonuc->v_v, px4tonuc->pitch, px4tonuc->roll, px4tonuc->yaw, px4tonuc->lon, px4tonuc->lat, px4tonuc->utc, px4tonuc->satellite_used, px4tonuc->gps_fix_type, px4tonuc->check_flag, px4tonuc->selfcheck_status, px4tonuc->tilt_of_platform, px4tonuc->Throwing_state, px4tonuc->work_finish_flag, px4tonuc->control_mode, px4tonuc->barometric_altitude, px4tonuc->radar_altitude, px4tonuc->acceleration_height, px4tonuc->satellite_altitude, px4tonuc->x_axis_acceleration, px4tonuc->y_axis_acceleration, px4tonuc->z_axis_acceleration, px4tonuc->x_axis_angula_velocity, px4tonuc->y_axis_angula_velocity, px4tonuc->z_axis_angula_velocity, px4tonuc->airspeed, px4tonuc->reserve_word1, px4tonuc->reserve_word2, px4tonuc->checksum);
}

/**
 * @brief Send a px4tonuc message
 * @param chan MAVLink channel to send the message
 *
 * @param frame_head  the frame head of the msg (microseconds since system boot or since UNIX epoch).
 * @param frame_num   to recongize the msg
 * @param frame_count  0-65535 
 * @param plane_status  to be configured by ourselves when needed(see introduction 2) 
 * @param instruction_status  to implicated whether the instruction is done(0 perfers to completed, 1 perfers to not)
 * @param waypoint_upload_flag  Waypoint upload flag:0-free|1-successful|2-defeat  
 * @param n_pos  Northward position
 * @param e_pos  Eastward position
 * @param fus_het  Fusion height 
 * @param n_v  Northward velocity
 * @param e_v  Eastward velocity
 * @param v_v  vertical velocity
 * @param pitch  pitch 
 * @param roll   roll 
 * @param yaw    yaw 
 * @param lon  longitude 
 * @param lat  latitude 
 * @param utc  utc 
 * @param satellite_used  satellite used 
 * @param gps_fix_type  fix_type (see vehicle_gps_position) 
 * @param check_flag  the flag implicating whether it finished self-check 
 * @param selfcheck_status  Different data bits represent different states 
 * @param tilt_of_platform    Tilt of platform, when use camera platform 
 * @param Throwing_state    0 prefers to do not throw,while 1 prefers to do  
 * @param work_finish_flag    0 prefers to do not need to update, 1 prefers to can update, the mission added by nuc, and px4 always returns 0
 * @param control_mode    40/41/42 angle controlling mode/Speed control mode/Position mode control 
 * @param barometric_altitude    Barometric altitude 
 * @param radar_altitude    Radar altitude 
 * @param acceleration_height    Acceleration Height 
 * @param satellite_altitude    Satellite altitude 
 * @param x_axis_acceleration   X_axis_acceleration short
 * @param y_axis_acceleration   y_axis_acceleration short
 * @param z_axis_acceleration   z_axis_acceleration short
 * @param x_axis_angula_velocity   x-axis angular velocity short
 * @param y_axis_angula_velocity   y-axis angular velocity short
 * @param z_axis_angula_velocity   z-axis angular velocity short
 * @param airspeed   cm/s
 * @param reserve_word1   unused word 
 * @param reserve_word2   unused word 
 * @param checksum    add up the data from the first place to the last place before checking, take 16 places lower 
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_px4tonuc_send(mavlink_channel_t chan, uint16_t frame_head, uint16_t frame_num, uint16_t frame_count, uint16_t plane_status, uint8_t instruction_status, uint8_t waypoint_upload_flag, int32_t n_pos, int32_t e_pos, int32_t fus_het, int32_t n_v, int32_t e_v, int32_t v_v, int16_t pitch, int16_t roll, int16_t yaw, int32_t lon, int32_t lat, int64_t utc, uint8_t satellite_used, uint8_t gps_fix_type, uint8_t check_flag, uint16_t selfcheck_status, int32_t tilt_of_platform, uint8_t Throwing_state, uint8_t work_finish_flag, uint8_t control_mode, int32_t barometric_altitude, int32_t radar_altitude, int32_t acceleration_height, int32_t satellite_altitude, int16_t x_axis_acceleration, int16_t y_axis_acceleration, int16_t z_axis_acceleration, int16_t x_axis_angula_velocity, int16_t y_axis_angula_velocity, int16_t z_axis_angula_velocity, int16_t airspeed, uint64_t reserve_word1, uint16_t reserve_word2, uint16_t checksum)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_PX4TONUC_LEN];
    _mav_put_int64_t(buf, 0, utc);
    _mav_put_uint64_t(buf, 8, reserve_word1);
    _mav_put_int32_t(buf, 16, n_pos);
    _mav_put_int32_t(buf, 20, e_pos);
    _mav_put_int32_t(buf, 24, fus_het);
    _mav_put_int32_t(buf, 28, n_v);
    _mav_put_int32_t(buf, 32, e_v);
    _mav_put_int32_t(buf, 36, v_v);
    _mav_put_int32_t(buf, 40, lon);
    _mav_put_int32_t(buf, 44, lat);
    _mav_put_int32_t(buf, 48, tilt_of_platform);
    _mav_put_int32_t(buf, 52, barometric_altitude);
    _mav_put_int32_t(buf, 56, radar_altitude);
    _mav_put_int32_t(buf, 60, acceleration_height);
    _mav_put_int32_t(buf, 64, satellite_altitude);
    _mav_put_uint16_t(buf, 68, frame_head);
    _mav_put_uint16_t(buf, 70, frame_num);
    _mav_put_uint16_t(buf, 72, frame_count);
    _mav_put_uint16_t(buf, 74, plane_status);
    _mav_put_int16_t(buf, 76, pitch);
    _mav_put_int16_t(buf, 78, roll);
    _mav_put_int16_t(buf, 80, yaw);
    _mav_put_uint16_t(buf, 82, selfcheck_status);
    _mav_put_int16_t(buf, 84, x_axis_acceleration);
    _mav_put_int16_t(buf, 86, y_axis_acceleration);
    _mav_put_int16_t(buf, 88, z_axis_acceleration);
    _mav_put_int16_t(buf, 90, x_axis_angula_velocity);
    _mav_put_int16_t(buf, 92, y_axis_angula_velocity);
    _mav_put_int16_t(buf, 94, z_axis_angula_velocity);
    _mav_put_int16_t(buf, 96, airspeed);
    _mav_put_uint16_t(buf, 98, reserve_word2);
    _mav_put_uint16_t(buf, 100, checksum);
    _mav_put_uint8_t(buf, 102, instruction_status);
    _mav_put_uint8_t(buf, 103, waypoint_upload_flag);
    _mav_put_uint8_t(buf, 104, satellite_used);
    _mav_put_uint8_t(buf, 105, gps_fix_type);
    _mav_put_uint8_t(buf, 106, check_flag);
    _mav_put_uint8_t(buf, 107, Throwing_state);
    _mav_put_uint8_t(buf, 108, work_finish_flag);
    _mav_put_uint8_t(buf, 109, control_mode);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_PX4TONUC, buf, MAVLINK_MSG_ID_PX4TONUC_MIN_LEN, MAVLINK_MSG_ID_PX4TONUC_LEN, MAVLINK_MSG_ID_PX4TONUC_CRC);
#else
    mavlink_px4tonuc_t packet;
    packet.utc = utc;
    packet.reserve_word1 = reserve_word1;
    packet.n_pos = n_pos;
    packet.e_pos = e_pos;
    packet.fus_het = fus_het;
    packet.n_v = n_v;
    packet.e_v = e_v;
    packet.v_v = v_v;
    packet.lon = lon;
    packet.lat = lat;
    packet.tilt_of_platform = tilt_of_platform;
    packet.barometric_altitude = barometric_altitude;
    packet.radar_altitude = radar_altitude;
    packet.acceleration_height = acceleration_height;
    packet.satellite_altitude = satellite_altitude;
    packet.frame_head = frame_head;
    packet.frame_num = frame_num;
    packet.frame_count = frame_count;
    packet.plane_status = plane_status;
    packet.pitch = pitch;
    packet.roll = roll;
    packet.yaw = yaw;
    packet.selfcheck_status = selfcheck_status;
    packet.x_axis_acceleration = x_axis_acceleration;
    packet.y_axis_acceleration = y_axis_acceleration;
    packet.z_axis_acceleration = z_axis_acceleration;
    packet.x_axis_angula_velocity = x_axis_angula_velocity;
    packet.y_axis_angula_velocity = y_axis_angula_velocity;
    packet.z_axis_angula_velocity = z_axis_angula_velocity;
    packet.airspeed = airspeed;
    packet.reserve_word2 = reserve_word2;
    packet.checksum = checksum;
    packet.instruction_status = instruction_status;
    packet.waypoint_upload_flag = waypoint_upload_flag;
    packet.satellite_used = satellite_used;
    packet.gps_fix_type = gps_fix_type;
    packet.check_flag = check_flag;
    packet.Throwing_state = Throwing_state;
    packet.work_finish_flag = work_finish_flag;
    packet.control_mode = control_mode;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_PX4TONUC, (const char *)&packet, MAVLINK_MSG_ID_PX4TONUC_MIN_LEN, MAVLINK_MSG_ID_PX4TONUC_LEN, MAVLINK_MSG_ID_PX4TONUC_CRC);
#endif
}

/**
 * @brief Send a px4tonuc message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_px4tonuc_send_struct(mavlink_channel_t chan, const mavlink_px4tonuc_t* px4tonuc)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_px4tonuc_send(chan, px4tonuc->frame_head, px4tonuc->frame_num, px4tonuc->frame_count, px4tonuc->plane_status, px4tonuc->instruction_status, px4tonuc->waypoint_upload_flag, px4tonuc->n_pos, px4tonuc->e_pos, px4tonuc->fus_het, px4tonuc->n_v, px4tonuc->e_v, px4tonuc->v_v, px4tonuc->pitch, px4tonuc->roll, px4tonuc->yaw, px4tonuc->lon, px4tonuc->lat, px4tonuc->utc, px4tonuc->satellite_used, px4tonuc->gps_fix_type, px4tonuc->check_flag, px4tonuc->selfcheck_status, px4tonuc->tilt_of_platform, px4tonuc->Throwing_state, px4tonuc->work_finish_flag, px4tonuc->control_mode, px4tonuc->barometric_altitude, px4tonuc->radar_altitude, px4tonuc->acceleration_height, px4tonuc->satellite_altitude, px4tonuc->x_axis_acceleration, px4tonuc->y_axis_acceleration, px4tonuc->z_axis_acceleration, px4tonuc->x_axis_angula_velocity, px4tonuc->y_axis_angula_velocity, px4tonuc->z_axis_angula_velocity, px4tonuc->airspeed, px4tonuc->reserve_word1, px4tonuc->reserve_word2, px4tonuc->checksum);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_PX4TONUC, (const char *)px4tonuc, MAVLINK_MSG_ID_PX4TONUC_MIN_LEN, MAVLINK_MSG_ID_PX4TONUC_LEN, MAVLINK_MSG_ID_PX4TONUC_CRC);
#endif
}

#if MAVLINK_MSG_ID_PX4TONUC_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_px4tonuc_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint16_t frame_head, uint16_t frame_num, uint16_t frame_count, uint16_t plane_status, uint8_t instruction_status, uint8_t waypoint_upload_flag, int32_t n_pos, int32_t e_pos, int32_t fus_het, int32_t n_v, int32_t e_v, int32_t v_v, int16_t pitch, int16_t roll, int16_t yaw, int32_t lon, int32_t lat, int64_t utc, uint8_t satellite_used, uint8_t gps_fix_type, uint8_t check_flag, uint16_t selfcheck_status, int32_t tilt_of_platform, uint8_t Throwing_state, uint8_t work_finish_flag, uint8_t control_mode, int32_t barometric_altitude, int32_t radar_altitude, int32_t acceleration_height, int32_t satellite_altitude, int16_t x_axis_acceleration, int16_t y_axis_acceleration, int16_t z_axis_acceleration, int16_t x_axis_angula_velocity, int16_t y_axis_angula_velocity, int16_t z_axis_angula_velocity, int16_t airspeed, uint64_t reserve_word1, uint16_t reserve_word2, uint16_t checksum)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_int64_t(buf, 0, utc);
    _mav_put_uint64_t(buf, 8, reserve_word1);
    _mav_put_int32_t(buf, 16, n_pos);
    _mav_put_int32_t(buf, 20, e_pos);
    _mav_put_int32_t(buf, 24, fus_het);
    _mav_put_int32_t(buf, 28, n_v);
    _mav_put_int32_t(buf, 32, e_v);
    _mav_put_int32_t(buf, 36, v_v);
    _mav_put_int32_t(buf, 40, lon);
    _mav_put_int32_t(buf, 44, lat);
    _mav_put_int32_t(buf, 48, tilt_of_platform);
    _mav_put_int32_t(buf, 52, barometric_altitude);
    _mav_put_int32_t(buf, 56, radar_altitude);
    _mav_put_int32_t(buf, 60, acceleration_height);
    _mav_put_int32_t(buf, 64, satellite_altitude);
    _mav_put_uint16_t(buf, 68, frame_head);
    _mav_put_uint16_t(buf, 70, frame_num);
    _mav_put_uint16_t(buf, 72, frame_count);
    _mav_put_uint16_t(buf, 74, plane_status);
    _mav_put_int16_t(buf, 76, pitch);
    _mav_put_int16_t(buf, 78, roll);
    _mav_put_int16_t(buf, 80, yaw);
    _mav_put_uint16_t(buf, 82, selfcheck_status);
    _mav_put_int16_t(buf, 84, x_axis_acceleration);
    _mav_put_int16_t(buf, 86, y_axis_acceleration);
    _mav_put_int16_t(buf, 88, z_axis_acceleration);
    _mav_put_int16_t(buf, 90, x_axis_angula_velocity);
    _mav_put_int16_t(buf, 92, y_axis_angula_velocity);
    _mav_put_int16_t(buf, 94, z_axis_angula_velocity);
    _mav_put_int16_t(buf, 96, airspeed);
    _mav_put_uint16_t(buf, 98, reserve_word2);
    _mav_put_uint16_t(buf, 100, checksum);
    _mav_put_uint8_t(buf, 102, instruction_status);
    _mav_put_uint8_t(buf, 103, waypoint_upload_flag);
    _mav_put_uint8_t(buf, 104, satellite_used);
    _mav_put_uint8_t(buf, 105, gps_fix_type);
    _mav_put_uint8_t(buf, 106, check_flag);
    _mav_put_uint8_t(buf, 107, Throwing_state);
    _mav_put_uint8_t(buf, 108, work_finish_flag);
    _mav_put_uint8_t(buf, 109, control_mode);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_PX4TONUC, buf, MAVLINK_MSG_ID_PX4TONUC_MIN_LEN, MAVLINK_MSG_ID_PX4TONUC_LEN, MAVLINK_MSG_ID_PX4TONUC_CRC);
#else
    mavlink_px4tonuc_t *packet = (mavlink_px4tonuc_t *)msgbuf;
    packet->utc = utc;
    packet->reserve_word1 = reserve_word1;
    packet->n_pos = n_pos;
    packet->e_pos = e_pos;
    packet->fus_het = fus_het;
    packet->n_v = n_v;
    packet->e_v = e_v;
    packet->v_v = v_v;
    packet->lon = lon;
    packet->lat = lat;
    packet->tilt_of_platform = tilt_of_platform;
    packet->barometric_altitude = barometric_altitude;
    packet->radar_altitude = radar_altitude;
    packet->acceleration_height = acceleration_height;
    packet->satellite_altitude = satellite_altitude;
    packet->frame_head = frame_head;
    packet->frame_num = frame_num;
    packet->frame_count = frame_count;
    packet->plane_status = plane_status;
    packet->pitch = pitch;
    packet->roll = roll;
    packet->yaw = yaw;
    packet->selfcheck_status = selfcheck_status;
    packet->x_axis_acceleration = x_axis_acceleration;
    packet->y_axis_acceleration = y_axis_acceleration;
    packet->z_axis_acceleration = z_axis_acceleration;
    packet->x_axis_angula_velocity = x_axis_angula_velocity;
    packet->y_axis_angula_velocity = y_axis_angula_velocity;
    packet->z_axis_angula_velocity = z_axis_angula_velocity;
    packet->airspeed = airspeed;
    packet->reserve_word2 = reserve_word2;
    packet->checksum = checksum;
    packet->instruction_status = instruction_status;
    packet->waypoint_upload_flag = waypoint_upload_flag;
    packet->satellite_used = satellite_used;
    packet->gps_fix_type = gps_fix_type;
    packet->check_flag = check_flag;
    packet->Throwing_state = Throwing_state;
    packet->work_finish_flag = work_finish_flag;
    packet->control_mode = control_mode;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_PX4TONUC, (const char *)packet, MAVLINK_MSG_ID_PX4TONUC_MIN_LEN, MAVLINK_MSG_ID_PX4TONUC_LEN, MAVLINK_MSG_ID_PX4TONUC_CRC);
#endif
}
#endif

#endif

// MESSAGE PX4TONUC UNPACKING


/**
 * @brief Get field frame_head from px4tonuc message
 *
 * @return  the frame head of the msg (microseconds since system boot or since UNIX epoch).
 */
static inline uint16_t mavlink_msg_px4tonuc_get_frame_head(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  68);
}

/**
 * @brief Get field frame_num from px4tonuc message
 *
 * @return   to recongize the msg
 */
static inline uint16_t mavlink_msg_px4tonuc_get_frame_num(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  70);
}

/**
 * @brief Get field frame_count from px4tonuc message
 *
 * @return  0-65535 
 */
static inline uint16_t mavlink_msg_px4tonuc_get_frame_count(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  72);
}

/**
 * @brief Get field plane_status from px4tonuc message
 *
 * @return  to be configured by ourselves when needed(see introduction 2) 
 */
static inline uint16_t mavlink_msg_px4tonuc_get_plane_status(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  74);
}

/**
 * @brief Get field instruction_status from px4tonuc message
 *
 * @return  to implicated whether the instruction is done(0 perfers to completed, 1 perfers to not)
 */
static inline uint8_t mavlink_msg_px4tonuc_get_instruction_status(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  102);
}

/**
 * @brief Get field waypoint_upload_flag from px4tonuc message
 *
 * @return  Waypoint upload flag:0-free|1-successful|2-defeat  
 */
static inline uint8_t mavlink_msg_px4tonuc_get_waypoint_upload_flag(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  103);
}

/**
 * @brief Get field n_pos from px4tonuc message
 *
 * @return  Northward position
 */
static inline int32_t mavlink_msg_px4tonuc_get_n_pos(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  16);
}

/**
 * @brief Get field e_pos from px4tonuc message
 *
 * @return  Eastward position
 */
static inline int32_t mavlink_msg_px4tonuc_get_e_pos(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  20);
}

/**
 * @brief Get field fus_het from px4tonuc message
 *
 * @return  Fusion height 
 */
static inline int32_t mavlink_msg_px4tonuc_get_fus_het(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  24);
}

/**
 * @brief Get field n_v from px4tonuc message
 *
 * @return  Northward velocity
 */
static inline int32_t mavlink_msg_px4tonuc_get_n_v(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  28);
}

/**
 * @brief Get field e_v from px4tonuc message
 *
 * @return  Eastward velocity
 */
static inline int32_t mavlink_msg_px4tonuc_get_e_v(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  32);
}

/**
 * @brief Get field v_v from px4tonuc message
 *
 * @return  vertical velocity
 */
static inline int32_t mavlink_msg_px4tonuc_get_v_v(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  36);
}

/**
 * @brief Get field pitch from px4tonuc message
 *
 * @return  pitch 
 */
static inline int16_t mavlink_msg_px4tonuc_get_pitch(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  76);
}

/**
 * @brief Get field roll from px4tonuc message
 *
 * @return   roll 
 */
static inline int16_t mavlink_msg_px4tonuc_get_roll(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  78);
}

/**
 * @brief Get field yaw from px4tonuc message
 *
 * @return    yaw 
 */
static inline int16_t mavlink_msg_px4tonuc_get_yaw(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  80);
}

/**
 * @brief Get field lon from px4tonuc message
 *
 * @return  longitude 
 */
static inline int32_t mavlink_msg_px4tonuc_get_lon(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  40);
}

/**
 * @brief Get field lat from px4tonuc message
 *
 * @return  latitude 
 */
static inline int32_t mavlink_msg_px4tonuc_get_lat(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  44);
}

/**
 * @brief Get field utc from px4tonuc message
 *
 * @return  utc 
 */
static inline int64_t mavlink_msg_px4tonuc_get_utc(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int64_t(msg,  0);
}

/**
 * @brief Get field satellite_used from px4tonuc message
 *
 * @return  satellite used 
 */
static inline uint8_t mavlink_msg_px4tonuc_get_satellite_used(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  104);
}

/**
 * @brief Get field gps_fix_type from px4tonuc message
 *
 * @return  fix_type (see vehicle_gps_position) 
 */
static inline uint8_t mavlink_msg_px4tonuc_get_gps_fix_type(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  105);
}

/**
 * @brief Get field check_flag from px4tonuc message
 *
 * @return  the flag implicating whether it finished self-check 
 */
static inline uint8_t mavlink_msg_px4tonuc_get_check_flag(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  106);
}

/**
 * @brief Get field selfcheck_status from px4tonuc message
 *
 * @return  Different data bits represent different states 
 */
static inline uint16_t mavlink_msg_px4tonuc_get_selfcheck_status(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  82);
}

/**
 * @brief Get field tilt_of_platform from px4tonuc message
 *
 * @return    Tilt of platform, when use camera platform 
 */
static inline int32_t mavlink_msg_px4tonuc_get_tilt_of_platform(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  48);
}

/**
 * @brief Get field Throwing_state from px4tonuc message
 *
 * @return    0 prefers to do not throw,while 1 prefers to do  
 */
static inline uint8_t mavlink_msg_px4tonuc_get_Throwing_state(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  107);
}

/**
 * @brief Get field work_finish_flag from px4tonuc message
 *
 * @return    0 prefers to do not need to update, 1 prefers to can update, the mission added by nuc, and px4 always returns 0
 */
static inline uint8_t mavlink_msg_px4tonuc_get_work_finish_flag(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  108);
}

/**
 * @brief Get field control_mode from px4tonuc message
 *
 * @return    40/41/42 angle controlling mode/Speed control mode/Position mode control 
 */
static inline uint8_t mavlink_msg_px4tonuc_get_control_mode(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  109);
}

/**
 * @brief Get field barometric_altitude from px4tonuc message
 *
 * @return    Barometric altitude 
 */
static inline int32_t mavlink_msg_px4tonuc_get_barometric_altitude(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  52);
}

/**
 * @brief Get field radar_altitude from px4tonuc message
 *
 * @return    Radar altitude 
 */
static inline int32_t mavlink_msg_px4tonuc_get_radar_altitude(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  56);
}

/**
 * @brief Get field acceleration_height from px4tonuc message
 *
 * @return    Acceleration Height 
 */
static inline int32_t mavlink_msg_px4tonuc_get_acceleration_height(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  60);
}

/**
 * @brief Get field satellite_altitude from px4tonuc message
 *
 * @return    Satellite altitude 
 */
static inline int32_t mavlink_msg_px4tonuc_get_satellite_altitude(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  64);
}

/**
 * @brief Get field x_axis_acceleration from px4tonuc message
 *
 * @return   X_axis_acceleration short
 */
static inline int16_t mavlink_msg_px4tonuc_get_x_axis_acceleration(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  84);
}

/**
 * @brief Get field y_axis_acceleration from px4tonuc message
 *
 * @return   y_axis_acceleration short
 */
static inline int16_t mavlink_msg_px4tonuc_get_y_axis_acceleration(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  86);
}

/**
 * @brief Get field z_axis_acceleration from px4tonuc message
 *
 * @return   z_axis_acceleration short
 */
static inline int16_t mavlink_msg_px4tonuc_get_z_axis_acceleration(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  88);
}

/**
 * @brief Get field x_axis_angula_velocity from px4tonuc message
 *
 * @return   x-axis angular velocity short
 */
static inline int16_t mavlink_msg_px4tonuc_get_x_axis_angula_velocity(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  90);
}

/**
 * @brief Get field y_axis_angula_velocity from px4tonuc message
 *
 * @return   y-axis angular velocity short
 */
static inline int16_t mavlink_msg_px4tonuc_get_y_axis_angula_velocity(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  92);
}

/**
 * @brief Get field z_axis_angula_velocity from px4tonuc message
 *
 * @return   z-axis angular velocity short
 */
static inline int16_t mavlink_msg_px4tonuc_get_z_axis_angula_velocity(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  94);
}

/**
 * @brief Get field airspeed from px4tonuc message
 *
 * @return   cm/s
 */
static inline int16_t mavlink_msg_px4tonuc_get_airspeed(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  96);
}

/**
 * @brief Get field reserve_word1 from px4tonuc message
 *
 * @return   unused word 
 */
static inline uint64_t mavlink_msg_px4tonuc_get_reserve_word1(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint64_t(msg,  8);
}

/**
 * @brief Get field reserve_word2 from px4tonuc message
 *
 * @return   unused word 
 */
static inline uint16_t mavlink_msg_px4tonuc_get_reserve_word2(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  98);
}

/**
 * @brief Get field checksum from px4tonuc message
 *
 * @return    add up the data from the first place to the last place before checking, take 16 places lower 
 */
static inline uint16_t mavlink_msg_px4tonuc_get_checksum(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  100);
}

/**
 * @brief Decode a px4tonuc message into a struct
 *
 * @param msg The message to decode
 * @param px4tonuc C-struct to decode the message contents into
 */
static inline void mavlink_msg_px4tonuc_decode(const mavlink_message_t* msg, mavlink_px4tonuc_t* px4tonuc)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    px4tonuc->utc = mavlink_msg_px4tonuc_get_utc(msg);
    px4tonuc->reserve_word1 = mavlink_msg_px4tonuc_get_reserve_word1(msg);
    px4tonuc->n_pos = mavlink_msg_px4tonuc_get_n_pos(msg);
    px4tonuc->e_pos = mavlink_msg_px4tonuc_get_e_pos(msg);
    px4tonuc->fus_het = mavlink_msg_px4tonuc_get_fus_het(msg);
    px4tonuc->n_v = mavlink_msg_px4tonuc_get_n_v(msg);
    px4tonuc->e_v = mavlink_msg_px4tonuc_get_e_v(msg);
    px4tonuc->v_v = mavlink_msg_px4tonuc_get_v_v(msg);
    px4tonuc->lon = mavlink_msg_px4tonuc_get_lon(msg);
    px4tonuc->lat = mavlink_msg_px4tonuc_get_lat(msg);
    px4tonuc->tilt_of_platform = mavlink_msg_px4tonuc_get_tilt_of_platform(msg);
    px4tonuc->barometric_altitude = mavlink_msg_px4tonuc_get_barometric_altitude(msg);
    px4tonuc->radar_altitude = mavlink_msg_px4tonuc_get_radar_altitude(msg);
    px4tonuc->acceleration_height = mavlink_msg_px4tonuc_get_acceleration_height(msg);
    px4tonuc->satellite_altitude = mavlink_msg_px4tonuc_get_satellite_altitude(msg);
    px4tonuc->frame_head = mavlink_msg_px4tonuc_get_frame_head(msg);
    px4tonuc->frame_num = mavlink_msg_px4tonuc_get_frame_num(msg);
    px4tonuc->frame_count = mavlink_msg_px4tonuc_get_frame_count(msg);
    px4tonuc->plane_status = mavlink_msg_px4tonuc_get_plane_status(msg);
    px4tonuc->pitch = mavlink_msg_px4tonuc_get_pitch(msg);
    px4tonuc->roll = mavlink_msg_px4tonuc_get_roll(msg);
    px4tonuc->yaw = mavlink_msg_px4tonuc_get_yaw(msg);
    px4tonuc->selfcheck_status = mavlink_msg_px4tonuc_get_selfcheck_status(msg);
    px4tonuc->x_axis_acceleration = mavlink_msg_px4tonuc_get_x_axis_acceleration(msg);
    px4tonuc->y_axis_acceleration = mavlink_msg_px4tonuc_get_y_axis_acceleration(msg);
    px4tonuc->z_axis_acceleration = mavlink_msg_px4tonuc_get_z_axis_acceleration(msg);
    px4tonuc->x_axis_angula_velocity = mavlink_msg_px4tonuc_get_x_axis_angula_velocity(msg);
    px4tonuc->y_axis_angula_velocity = mavlink_msg_px4tonuc_get_y_axis_angula_velocity(msg);
    px4tonuc->z_axis_angula_velocity = mavlink_msg_px4tonuc_get_z_axis_angula_velocity(msg);
    px4tonuc->airspeed = mavlink_msg_px4tonuc_get_airspeed(msg);
    px4tonuc->reserve_word2 = mavlink_msg_px4tonuc_get_reserve_word2(msg);
    px4tonuc->checksum = mavlink_msg_px4tonuc_get_checksum(msg);
    px4tonuc->instruction_status = mavlink_msg_px4tonuc_get_instruction_status(msg);
    px4tonuc->waypoint_upload_flag = mavlink_msg_px4tonuc_get_waypoint_upload_flag(msg);
    px4tonuc->satellite_used = mavlink_msg_px4tonuc_get_satellite_used(msg);
    px4tonuc->gps_fix_type = mavlink_msg_px4tonuc_get_gps_fix_type(msg);
    px4tonuc->check_flag = mavlink_msg_px4tonuc_get_check_flag(msg);
    px4tonuc->Throwing_state = mavlink_msg_px4tonuc_get_Throwing_state(msg);
    px4tonuc->work_finish_flag = mavlink_msg_px4tonuc_get_work_finish_flag(msg);
    px4tonuc->control_mode = mavlink_msg_px4tonuc_get_control_mode(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_PX4TONUC_LEN? msg->len : MAVLINK_MSG_ID_PX4TONUC_LEN;
        memset(px4tonuc, 0, MAVLINK_MSG_ID_PX4TONUC_LEN);
    memcpy(px4tonuc, _MAV_PAYLOAD(msg), len);
#endif
}
