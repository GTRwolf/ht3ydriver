// MESSAGE NUC_MODE_CONT support class

#pragma once

namespace mavlink {
namespace ht3y {
namespace msg {

/**
 * @brief NUC_MODE_CONT message
 *
 * HTSY need the msg which NUC sends to px4
 */
struct NUC_MODE_CONT : mavlink::Message {
    static constexpr msgid_t MSG_ID = 202;
    static constexpr size_t LENGTH = 36;
    static constexpr size_t MIN_LENGTH = 36;
    static constexpr uint8_t CRC_EXTRA = 96;
    static constexpr auto NAME = "NUC_MODE_CONT";


    uint16_t frame_head; /*<  the frame head of the msg (microseconds since system boot or since UNIX epoch). */
    uint16_t frame_num; /*<   to recongize the msg */
    uint8_t order_seq; /*<  0-255  */
    uint16_t frame_seq; /*<  0-65535 */
    uint8_t control_mode; /*<   --  */
    float param1; /*<  different mode has different meanings.(roll/speed_x/lon) */
    float param2; /*<  (pitch/speed_y/lat) */
    float param3; /*<  (none /speed_z/alt) */
    float param4; /*<  (nz) */
    float yaw; /*<  degree */
    uint8_t yaw_use; /*<   the flag indicated whether used yaw,direction of rotation, 0 clockwise, 1 anticlockwise */
    int16_t tilt_of_platform; /*<  -90-90 degree  */
    uint8_t package_length; /*<  the length of this msg or pack   */
    uint8_t package_id; /*<  the msgid of this pack  */
    uint8_t reserve_word; /*<  unused word  */
    uint16_t checksum; /*<    add up the data from the first place to the last place before checking, take 16 places lower  */


    inline std::string get_name(void) const override
    {
            return NAME;
    }

    inline Info get_message_info(void) const override
    {
            return { MSG_ID, LENGTH, MIN_LENGTH, CRC_EXTRA };
    }

    inline std::string to_yaml(void) const override
    {
        std::stringstream ss;

        ss << NAME << ":" << std::endl;
        ss << "  frame_head: " << frame_head << std::endl;
        ss << "  frame_num: " << frame_num << std::endl;
        ss << "  order_seq: " << +order_seq << std::endl;
        ss << "  frame_seq: " << frame_seq << std::endl;
        ss << "  control_mode: " << +control_mode << std::endl;
        ss << "  param1: " << param1 << std::endl;
        ss << "  param2: " << param2 << std::endl;
        ss << "  param3: " << param3 << std::endl;
        ss << "  param4: " << param4 << std::endl;
        ss << "  yaw: " << yaw << std::endl;
        ss << "  yaw_use: " << +yaw_use << std::endl;
        ss << "  tilt_of_platform: " << tilt_of_platform << std::endl;
        ss << "  package_length: " << +package_length << std::endl;
        ss << "  package_id: " << +package_id << std::endl;
        ss << "  reserve_word: " << +reserve_word << std::endl;
        ss << "  checksum: " << checksum << std::endl;

        return ss.str();
    }

    inline void serialize(mavlink::MsgMap &map) const override
    {
        map.reset(MSG_ID, LENGTH);

        map << param1;                        // offset: 0
        map << param2;                        // offset: 4
        map << param3;                        // offset: 8
        map << param4;                        // offset: 12
        map << yaw;                           // offset: 16
        map << frame_head;                    // offset: 20
        map << frame_num;                     // offset: 22
        map << frame_seq;                     // offset: 24
        map << tilt_of_platform;              // offset: 26
        map << checksum;                      // offset: 28
        map << order_seq;                     // offset: 30
        map << control_mode;                  // offset: 31
        map << yaw_use;                       // offset: 32
        map << package_length;                // offset: 33
        map << package_id;                    // offset: 34
        map << reserve_word;                  // offset: 35
    }

    inline void deserialize(mavlink::MsgMap &map) override
    {
        map >> param1;                        // offset: 0
        map >> param2;                        // offset: 4
        map >> param3;                        // offset: 8
        map >> param4;                        // offset: 12
        map >> yaw;                           // offset: 16
        map >> frame_head;                    // offset: 20
        map >> frame_num;                     // offset: 22
        map >> frame_seq;                     // offset: 24
        map >> tilt_of_platform;              // offset: 26
        map >> checksum;                      // offset: 28
        map >> order_seq;                     // offset: 30
        map >> control_mode;                  // offset: 31
        map >> yaw_use;                       // offset: 32
        map >> package_length;                // offset: 33
        map >> package_id;                    // offset: 34
        map >> reserve_word;                  // offset: 35
    }
};

} // namespace msg
} // namespace ht3y
} // namespace mavlink
