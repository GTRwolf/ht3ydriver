/** @file
 *	@brief MAVLink comm protocol generated from ht3y.xml
 *	@see http://mavlink.org
 */

#pragma once

#include <array>
#include <cstdint>
#include <sstream>

#ifndef MAVLINK_STX
#define MAVLINK_STX 253
#endif

#include "../message.hpp"

namespace mavlink {
namespace ht3y {

/**
 * Array of msg_entry needed for @p mavlink_parse_char() (trought @p mavlink_get_msg_entry())
 */
constexpr std::array<mavlink_msg_entry_t, 3> MESSAGE_ENTRIES {{ {200, 80, 110, 0, 0, 0}, {201, 173, 24, 0, 0, 0}, {202, 96, 36, 0, 0, 0} }};

//! MAVLINK VERSION
constexpr auto MAVLINK_VERSION = 2;


// ENUM DEFINITIONS




} // namespace ht3y
} // namespace mavlink

// MESSAGE DEFINITIONS
#include "./mavlink_msg_px4tonuc.hpp"
#include "./mavlink_msg_nuc_action_cont.hpp"
#include "./mavlink_msg_nuc_mode_cont.hpp"

// base include
#include "../common/common.hpp"
