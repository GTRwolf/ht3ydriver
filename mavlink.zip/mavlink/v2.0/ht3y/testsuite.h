/** @file
 *    @brief MAVLink comm protocol testsuite generated from ht3y.xml
 *    @see http://qgroundcontrol.org/mavlink/
 */
#pragma once
#ifndef HT3Y_TESTSUITE_H
#define HT3Y_TESTSUITE_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef MAVLINK_TEST_ALL
#define MAVLINK_TEST_ALL
static void mavlink_test_common(uint8_t, uint8_t, mavlink_message_t *last_msg);
static void mavlink_test_ht3y(uint8_t, uint8_t, mavlink_message_t *last_msg);

static void mavlink_test_all(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
    mavlink_test_common(system_id, component_id, last_msg);
    mavlink_test_ht3y(system_id, component_id, last_msg);
}
#endif

#include "../common/testsuite.h"


static void mavlink_test_px4tonuc(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_PX4TONUC >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_px4tonuc_t packet_in = {
        93372036854775807LL,93372036854776311ULL,963498296,963498504,963498712,963498920,963499128,963499336,963499544,963499752,963499960,963500168,963500376,963500584,963500792,20771,20875,20979,21083,21187,21291,21395,21499,21603,21707,21811,21915,22019,22123,22227,22331,22435,183,250,61,128,195,6,73,140
    };
    mavlink_px4tonuc_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.utc = packet_in.utc;
        packet1.reserve_word1 = packet_in.reserve_word1;
        packet1.n_pos = packet_in.n_pos;
        packet1.e_pos = packet_in.e_pos;
        packet1.fus_het = packet_in.fus_het;
        packet1.n_v = packet_in.n_v;
        packet1.e_v = packet_in.e_v;
        packet1.v_v = packet_in.v_v;
        packet1.lon = packet_in.lon;
        packet1.lat = packet_in.lat;
        packet1.tilt_of_platform = packet_in.tilt_of_platform;
        packet1.barometric_altitude = packet_in.barometric_altitude;
        packet1.radar_altitude = packet_in.radar_altitude;
        packet1.acceleration_height = packet_in.acceleration_height;
        packet1.satellite_altitude = packet_in.satellite_altitude;
        packet1.frame_head = packet_in.frame_head;
        packet1.frame_num = packet_in.frame_num;
        packet1.frame_count = packet_in.frame_count;
        packet1.plane_status = packet_in.plane_status;
        packet1.pitch = packet_in.pitch;
        packet1.roll = packet_in.roll;
        packet1.yaw = packet_in.yaw;
        packet1.selfcheck_status = packet_in.selfcheck_status;
        packet1.x_axis_acceleration = packet_in.x_axis_acceleration;
        packet1.y_axis_acceleration = packet_in.y_axis_acceleration;
        packet1.z_axis_acceleration = packet_in.z_axis_acceleration;
        packet1.x_axis_angula_velocity = packet_in.x_axis_angula_velocity;
        packet1.y_axis_angula_velocity = packet_in.y_axis_angula_velocity;
        packet1.z_axis_angula_velocity = packet_in.z_axis_angula_velocity;
        packet1.airspeed = packet_in.airspeed;
        packet1.reserve_word2 = packet_in.reserve_word2;
        packet1.checksum = packet_in.checksum;
        packet1.instruction_status = packet_in.instruction_status;
        packet1.waypoint_upload_flag = packet_in.waypoint_upload_flag;
        packet1.satellite_used = packet_in.satellite_used;
        packet1.gps_fix_type = packet_in.gps_fix_type;
        packet1.check_flag = packet_in.check_flag;
        packet1.Throwing_state = packet_in.Throwing_state;
        packet1.work_finish_flag = packet_in.work_finish_flag;
        packet1.control_mode = packet_in.control_mode;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_PX4TONUC_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_PX4TONUC_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_px4tonuc_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_px4tonuc_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_px4tonuc_pack(system_id, component_id, &msg , packet1.frame_head , packet1.frame_num , packet1.frame_count , packet1.plane_status , packet1.instruction_status , packet1.waypoint_upload_flag , packet1.n_pos , packet1.e_pos , packet1.fus_het , packet1.n_v , packet1.e_v , packet1.v_v , packet1.pitch , packet1.roll , packet1.yaw , packet1.lon , packet1.lat , packet1.utc , packet1.satellite_used , packet1.gps_fix_type , packet1.check_flag , packet1.selfcheck_status , packet1.tilt_of_platform , packet1.Throwing_state , packet1.work_finish_flag , packet1.control_mode , packet1.barometric_altitude , packet1.radar_altitude , packet1.acceleration_height , packet1.satellite_altitude , packet1.x_axis_acceleration , packet1.y_axis_acceleration , packet1.z_axis_acceleration , packet1.x_axis_angula_velocity , packet1.y_axis_angula_velocity , packet1.z_axis_angula_velocity , packet1.airspeed , packet1.reserve_word1 , packet1.reserve_word2 , packet1.checksum );
    mavlink_msg_px4tonuc_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_px4tonuc_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.frame_head , packet1.frame_num , packet1.frame_count , packet1.plane_status , packet1.instruction_status , packet1.waypoint_upload_flag , packet1.n_pos , packet1.e_pos , packet1.fus_het , packet1.n_v , packet1.e_v , packet1.v_v , packet1.pitch , packet1.roll , packet1.yaw , packet1.lon , packet1.lat , packet1.utc , packet1.satellite_used , packet1.gps_fix_type , packet1.check_flag , packet1.selfcheck_status , packet1.tilt_of_platform , packet1.Throwing_state , packet1.work_finish_flag , packet1.control_mode , packet1.barometric_altitude , packet1.radar_altitude , packet1.acceleration_height , packet1.satellite_altitude , packet1.x_axis_acceleration , packet1.y_axis_acceleration , packet1.z_axis_acceleration , packet1.x_axis_angula_velocity , packet1.y_axis_angula_velocity , packet1.z_axis_angula_velocity , packet1.airspeed , packet1.reserve_word1 , packet1.reserve_word2 , packet1.checksum );
    mavlink_msg_px4tonuc_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_px4tonuc_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_px4tonuc_send(MAVLINK_COMM_1 , packet1.frame_head , packet1.frame_num , packet1.frame_count , packet1.plane_status , packet1.instruction_status , packet1.waypoint_upload_flag , packet1.n_pos , packet1.e_pos , packet1.fus_het , packet1.n_v , packet1.e_v , packet1.v_v , packet1.pitch , packet1.roll , packet1.yaw , packet1.lon , packet1.lat , packet1.utc , packet1.satellite_used , packet1.gps_fix_type , packet1.check_flag , packet1.selfcheck_status , packet1.tilt_of_platform , packet1.Throwing_state , packet1.work_finish_flag , packet1.control_mode , packet1.barometric_altitude , packet1.radar_altitude , packet1.acceleration_height , packet1.satellite_altitude , packet1.x_axis_acceleration , packet1.y_axis_acceleration , packet1.z_axis_acceleration , packet1.x_axis_angula_velocity , packet1.y_axis_angula_velocity , packet1.z_axis_angula_velocity , packet1.airspeed , packet1.reserve_word1 , packet1.reserve_word2 , packet1.checksum );
    mavlink_msg_px4tonuc_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_nuc_action_cont(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_NUC_ACTION_CONT >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_nuc_action_cont_t packet_in = {
        93372036854775807LL,963497880,17859,17963,18067,18171,18275,199,10
    };
    mavlink_nuc_action_cont_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.reserve_word = packet_in.reserve_word;
        packet1.altitude = packet_in.altitude;
        packet1.frame_head = packet_in.frame_head;
        packet1.frame_num = packet_in.frame_num;
        packet1.control_instruction = packet_in.control_instruction;
        packet1.frame_count = packet_in.frame_count;
        packet1.checksum = packet_in.checksum;
        packet1.command_count = packet_in.command_count;
        packet1.uav_num = packet_in.uav_num;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_NUC_ACTION_CONT_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_NUC_ACTION_CONT_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_nuc_action_cont_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_nuc_action_cont_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_nuc_action_cont_pack(system_id, component_id, &msg , packet1.frame_head , packet1.frame_num , packet1.command_count , packet1.control_instruction , packet1.frame_count , packet1.uav_num , packet1.altitude , packet1.reserve_word , packet1.checksum );
    mavlink_msg_nuc_action_cont_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_nuc_action_cont_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.frame_head , packet1.frame_num , packet1.command_count , packet1.control_instruction , packet1.frame_count , packet1.uav_num , packet1.altitude , packet1.reserve_word , packet1.checksum );
    mavlink_msg_nuc_action_cont_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_nuc_action_cont_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_nuc_action_cont_send(MAVLINK_COMM_1 , packet1.frame_head , packet1.frame_num , packet1.command_count , packet1.control_instruction , packet1.frame_count , packet1.uav_num , packet1.altitude , packet1.reserve_word , packet1.checksum );
    mavlink_msg_nuc_action_cont_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_nuc_mode_cont(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
    mavlink_status_t *status = mavlink_get_channel_status(MAVLINK_COMM_0);
        if ((status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) && MAVLINK_MSG_ID_NUC_MODE_CONT >= 256) {
            return;
        }
#endif
    mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
    mavlink_nuc_mode_cont_t packet_in = {
        17.0,45.0,73.0,101.0,129.0,18275,18379,18483,18587,18691,223,34,101,168,235,46
    };
    mavlink_nuc_mode_cont_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        packet1.param1 = packet_in.param1;
        packet1.param2 = packet_in.param2;
        packet1.param3 = packet_in.param3;
        packet1.param4 = packet_in.param4;
        packet1.yaw = packet_in.yaw;
        packet1.frame_head = packet_in.frame_head;
        packet1.frame_num = packet_in.frame_num;
        packet1.frame_seq = packet_in.frame_seq;
        packet1.tilt_of_platform = packet_in.tilt_of_platform;
        packet1.checksum = packet_in.checksum;
        packet1.order_seq = packet_in.order_seq;
        packet1.control_mode = packet_in.control_mode;
        packet1.yaw_use = packet_in.yaw_use;
        packet1.package_length = packet_in.package_length;
        packet1.package_id = packet_in.package_id;
        packet1.reserve_word = packet_in.reserve_word;
        
        
#ifdef MAVLINK_STATUS_FLAG_OUT_MAVLINK1
        if (status->flags & MAVLINK_STATUS_FLAG_OUT_MAVLINK1) {
           // cope with extensions
           memset(MAVLINK_MSG_ID_NUC_MODE_CONT_MIN_LEN + (char *)&packet1, 0, sizeof(packet1)-MAVLINK_MSG_ID_NUC_MODE_CONT_MIN_LEN);
        }
#endif
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_nuc_mode_cont_encode(system_id, component_id, &msg, &packet1);
    mavlink_msg_nuc_mode_cont_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_nuc_mode_cont_pack(system_id, component_id, &msg , packet1.frame_head , packet1.frame_num , packet1.order_seq , packet1.frame_seq , packet1.control_mode , packet1.param1 , packet1.param2 , packet1.param3 , packet1.param4 , packet1.yaw , packet1.yaw_use , packet1.tilt_of_platform , packet1.package_length , packet1.package_id , packet1.reserve_word , packet1.checksum );
    mavlink_msg_nuc_mode_cont_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_nuc_mode_cont_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.frame_head , packet1.frame_num , packet1.order_seq , packet1.frame_seq , packet1.control_mode , packet1.param1 , packet1.param2 , packet1.param3 , packet1.param4 , packet1.yaw , packet1.yaw_use , packet1.tilt_of_platform , packet1.package_length , packet1.package_id , packet1.reserve_word , packet1.checksum );
    mavlink_msg_nuc_mode_cont_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
            comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
    mavlink_msg_nuc_mode_cont_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
        
        memset(&packet2, 0, sizeof(packet2));
    mavlink_msg_nuc_mode_cont_send(MAVLINK_COMM_1 , packet1.frame_head , packet1.frame_num , packet1.order_seq , packet1.frame_seq , packet1.control_mode , packet1.param1 , packet1.param2 , packet1.param3 , packet1.param4 , packet1.yaw , packet1.yaw_use , packet1.tilt_of_platform , packet1.package_length , packet1.package_id , packet1.reserve_word , packet1.checksum );
    mavlink_msg_nuc_mode_cont_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_ht3y(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
    mavlink_test_px4tonuc(system_id, component_id, last_msg);
    mavlink_test_nuc_action_cont(system_id, component_id, last_msg);
    mavlink_test_nuc_mode_cont(system_id, component_id, last_msg);
}

#ifdef __cplusplus
}
#endif // __cplusplus
#endif // HT3Y_TESTSUITE_H
