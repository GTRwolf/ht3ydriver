// MESSAGE NUC_ACTION_CONT support class

#pragma once

namespace mavlink {
namespace ht3y {
namespace msg {

/**
 * @brief NUC_ACTION_CONT message
 *
 * HTSY need the msg which NUC sends to px4, it is used to control planes' action 
 */
struct NUC_ACTION_CONT : mavlink::Message {
    static constexpr msgid_t MSG_ID = 201;
    static constexpr size_t LENGTH = 24;
    static constexpr size_t MIN_LENGTH = 24;
    static constexpr uint8_t CRC_EXTRA = 173;
    static constexpr auto NAME = "NUC_ACTION_CONT";


    uint16_t frame_head; /*<  the frame head of the msg (microseconds since system boot or since UNIX epoch). */
    uint16_t frame_num; /*<   to recongize the msg */
    uint8_t command_count; /*<  0-255  */
    uint16_t control_instruction; /*<  (see introduction 1)  */
    uint16_t frame_count; /*<  0-65535 */
    uint8_t uav_num; /*<  the number of uav(px4)  */
    int32_t altitude; /*<  the information of altitude */
    int64_t reserve_word; /*<  unused word */
    uint16_t checksum; /*<    add up the data from the first place to the last place before checking, take 16 places lower   */


    inline std::string get_name(void) const override
    {
            return NAME;
    }

    inline Info get_message_info(void) const override
    {
            return { MSG_ID, LENGTH, MIN_LENGTH, CRC_EXTRA };
    }

    inline std::string to_yaml(void) const override
    {
        std::stringstream ss;

        ss << NAME << ":" << std::endl;
        ss << "  frame_head: " << frame_head << std::endl;
        ss << "  frame_num: " << frame_num << std::endl;
        ss << "  command_count: " << +command_count << std::endl;
        ss << "  control_instruction: " << control_instruction << std::endl;
        ss << "  frame_count: " << frame_count << std::endl;
        ss << "  uav_num: " << +uav_num << std::endl;
        ss << "  altitude: " << altitude << std::endl;
        ss << "  reserve_word: " << reserve_word << std::endl;
        ss << "  checksum: " << checksum << std::endl;

        return ss.str();
    }

    inline void serialize(mavlink::MsgMap &map) const override
    {
        map.reset(MSG_ID, LENGTH);

        map << reserve_word;                  // offset: 0
        map << altitude;                      // offset: 8
        map << frame_head;                    // offset: 12
        map << frame_num;                     // offset: 14
        map << control_instruction;           // offset: 16
        map << frame_count;                   // offset: 18
        map << checksum;                      // offset: 20
        map << command_count;                 // offset: 22
        map << uav_num;                       // offset: 23
    }

    inline void deserialize(mavlink::MsgMap &map) override
    {
        map >> reserve_word;                  // offset: 0
        map >> altitude;                      // offset: 8
        map >> frame_head;                    // offset: 12
        map >> frame_num;                     // offset: 14
        map >> control_instruction;           // offset: 16
        map >> frame_count;                   // offset: 18
        map >> checksum;                      // offset: 20
        map >> command_count;                 // offset: 22
        map >> uav_num;                       // offset: 23
    }
};

} // namespace msg
} // namespace ht3y
} // namespace mavlink
